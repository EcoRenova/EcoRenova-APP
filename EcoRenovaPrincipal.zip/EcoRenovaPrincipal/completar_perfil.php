<?php
session_start();

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header('Location: login_user.php'); // Redirige si no está logueado
    exit();
}

require 'conexion.php';
$con = conectar_bd(); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_usuario = $_SESSION['user_id']; // Asegúrate de que el ID de usuario esté en la sesión
    $apellido = mysqli_real_escape_string($con, $_POST['apellido']);
    $apodo = mysqli_real_escape_string($con, $_POST['apodo']);
    $edad = (int)$_POST['edad'];

    // Verifica si ya existe un perfil para el usuario
    $query_check = "SELECT COUNT(*) FROM perfil WHERE id_user = ?";
    $stmt_check = $con->prepare($query_check);
    $stmt_check->bind_param("i", $id_usuario);
    $stmt_check->execute();
    $stmt_check->bind_result($count);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($count > 0) {
        // Actualiza perfil existente (sin foto de perfil)
        $query = "UPDATE perfil SET apellido = ?, apodo = ?, edad = ? WHERE id_user = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("sssi", $apellido, $apodo, $edad, $id_usuario);
    } else {
        // Inserta nuevo perfil (sin foto de perfil)
        $query = "INSERT INTO perfil (id_user, apellido, apodo, edad) VALUES (?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param("isss", $id_usuario, $apellido, $apodo, $edad);
    }
    
    if ($stmt->execute()) {
        // Almacena el apodo en la sesión
        $_SESSION['apodo'] = $apodo;
        header('Location: index.php'); // Redirige a la página principal
        exit();
    } else {
        echo "Error al guardar el perfil: " . $stmt->error;
    }
    $stmt->close();
}

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completar Perfil</title>
    <link rel="stylesheet" href="/css/perfil.css">
</head>
<body>
    <div class="cont-complete-perfil">
        <h2 class="comp-profile-title">Completa tu Perfil</h2>
        <form class="profile-form" action="completar_perfil.php" method="POST">
            <div class="form-group">
                <label class="label-apellido" for="apellido">Apellido:</label>
                <input class="input-apellido" autocomplete="off" type="text" id="apellido" name="apellido" required>
            </div>

            <div class="form-group">
                <label class="label-apodo" for="apodo">Nombre De Usuario:</label>
                <input class="input-apodo" autocomplete="off" type="text" id="apodo" name="apodo" required>
            </div>

            <div class="form-group">
                <label class="label-edad" for="edad">Edad:</label>
                <input class="input-edad" autocomplete="off" type="number" id="edad" name="edad" required>
            </div>
            <button class="submit-button" type="submit">Guardar Perfil</button>
        </form>
    </div>
</body>
</html>
