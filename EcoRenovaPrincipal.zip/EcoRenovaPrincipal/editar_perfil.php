<?php
session_start();

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header('Location: login_user.php'); // Redirige si no está logueado
    exit();
}

require 'conexion.php';

// Verifica la conexión a la base de datos
$con = conectar_bd();
if (!$con) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtener el ID de usuario de la sesión
$id_usuario = $_SESSION['user_id'];

// Consulta para obtener los datos del usuario
$query = "SELECT nombre, 
                 (SELECT apodo FROM perfil WHERE id_user = ?) AS apodo,
                 (SELECT biografia FROM perfil WHERE id_user = ?) AS biografia
          FROM usuario 
          WHERE id_user = ?";
$stmt = $con->prepare($query);

// Verifica si la preparación fue exitosa
if ($stmt === false) {
    die("Error en la preparación de la declaración: " . $con->error);
}

$stmt->bind_param("iii", $id_usuario, $id_usuario, $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $nombre_usuario = $user['nombre']; 
    $apodo = $user['apodo'];
    $biografia = $user['biografia'];
} else {
    // si el usuario no fue encontrado...
    echo "Usuario no encontrado.";
    exit();
}

$stmt->close();
$con->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="editarperfilbody">
    <div class="form-container">
        <h2>Editar Perfil</h2>
        <form action="actualizar_perfil.php" method="POST" class="form-editar-perfil">
            <div class="form-group">
                <label for="nombre_usuario">Nombre de usuario</label>
                <input type="text" name="nombre_usuario" id="nombre_usuario" value="<?php echo htmlspecialchars($nombre_usuario); ?>" required>
            </div>
            <div class="form-group">
                <label for="apodo">Apodo</label>
                <input type="text" name="apodo" id="apodo" value="<?php echo htmlspecialchars($apodo); ?>" required>
            </div>
            <div class="form-group">
                <label for="biografia">Biografía</label>
                <textarea name="biografia" id="biografia" required><?php echo htmlspecialchars($biografia); ?></textarea>
            </div>
            <button type="submit">Guardar cambios</button>
            <a class="volverbuttonperfil" href="verperfil.php">volver</a>
        </form>
    </div>
</body>
</html>
