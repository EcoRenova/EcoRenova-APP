<?php
function conectar_bd() {
    $host = 'localhost';
    $usuario = 'root'; 
    $clave = ''; 
    $base_datos = 'ecorenovas'; 

    // Esto crea la conexión
    $conn = new mysqli($host, $usuario, $clave, $base_datos);

    // Esto verifica la conexión
    if ($conn->connect_error) {
        die('Conexión fallida: ' . $conn->connect_error);
    }
    return $conn;
}
?>
