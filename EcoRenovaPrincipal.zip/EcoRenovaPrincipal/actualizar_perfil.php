<?php
session_start();

// Verifica si el usuario inicio sesión
if (!isset($_SESSION['email'])) {
    header('Location: login_user.php');
    exit();
}

require 'conexion.php';

// Verifica la conexión a la base de datos
$con = conectar_bd();
if (!$con) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Obtiene la id del ususario de la session
$id_usuario = $_SESSION['user_id'];

// Obtiene los datos del formulario 
$nombre_usuario = $_POST['nombre_usuario'];
$apodo = $_POST['apodo'];
$biografia = $_POST['biografia'];

// Actualiza los datos en la base de datos
$query = "UPDATE usuario SET nombre = ? WHERE id_user = ?";
$stmt = $con->prepare($query);
$stmt->bind_param("si", $nombre_usuario, $id_usuario);
$stmt->execute();

$query2 = "UPDATE perfil SET apodo = ?, biografia = ? WHERE id_user = ?";
$stmt2 = $con->prepare($query2);
$stmt2->bind_param("ssi", $apodo, $biografia, $id_usuario);
$stmt2->execute();

// Cerrar la conexion
$stmt->close();
$stmt2->close();
$con->close();

// Redirige al perfil actualizado
header('Location: verperfil.php');
exit();
?>
