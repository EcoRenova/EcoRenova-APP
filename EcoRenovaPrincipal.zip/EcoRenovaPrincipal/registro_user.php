<?php
require("conexion.php");

$con = conectar_bd();

// Comprobar que se envió el formulario por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["nombre"]) && isset($_POST["email"]) && isset($_POST["pass"])) {
    $nombre = mysqli_real_escape_string($con, $_POST["nombre"]);
    $email = mysqli_real_escape_string($con, $_POST["email"]);
    $contrasenia = $_POST["pass"];

    // Consultar si el usuario ya existe
    if (!consultar_existe_usr($con, $email)) {
        // Si el usuario no existe se van a insertar datos
        if (insertar_datos($con, $nombre, $email, $contrasenia)) {
            // Obtener el ID del usuario recién creado
            $id_usuario = mysqli_insert_id($con);
            
            // Iniciar la sesión y redireccionar a completar_perfil.php
            session_start();
            $_SESSION['user_id'] = $id_usuario; 
            $_SESSION['email'] = $email; 
            header("Location: completar_perfil.php");
            exit(); 
        } else {
            // desde aca son los mensajes de depuracion
            echo "Error al registrar el usuario: " . mysqli_error($con); 
        }
    } else {
        echo "El usuario ya existe.";
    }
} else {
    echo "Por favor completa todos los campos.";
}

// Función para consultar si el usuario ya existe
function consultar_existe_usr($con, $email) {
    $consulta_existe_usr = "SELECT email FROM usuario WHERE email = '$email'";
    $resultado_existe_usr = mysqli_query($con, $consulta_existe_usr);
    
    return mysqli_num_rows($resultado_existe_usr) > 0;
}

// Función para insertar datos
function insertar_datos($con, $nombre, $email, $contrasenia) {
    $contrasenia_hash = password_hash($contrasenia, PASSWORD_DEFAULT);
    
    $consulta_insertar = "INSERT INTO usuario (nombre, email, pass) VALUES ('$nombre', '$email', '$contrasenia_hash')";

    return mysqli_query($con, $consulta_insertar);
}

mysqli_close($con);
?>
