<?php
session_start(); // Inicia la sesión

if (!isset($_SESSION['user_id'])) {
    header('Location: login_user.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>EcoMarket</title>

    <!-- FUENTE GOOGLE FONTS : Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- ICONS: Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

    <!-- ICONS: Line Awesome -->
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Animaciones AOS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css">

    <!-- Mis Estilos -->
    <link rel="stylesheet" href="estilosmercado.css">

    <?php include 'conexion.php'; ?>
</head>
<body>
<div class="hm-wrapper">
    <div class="hm-header">
    <div class="container">
        <div class="header-menu">
            <div class="hm-logo">
                <a class="alogo" href="#">
                  <h1 class="logotxt">EcoMarket</h1> 
                </a>
           </div>
                <nav class="hm-menu">
                    <ul>
                        <li><a href="#">Inicio</a></li>
                        <li><a href="#productos">Productos</a></li>
                        <li><a href="crear_publicacion.php">Crear Publicación</a></li>
                        <li><a href="index.php">Volver a EcoRenova</a></li>
                    </ul>
                        <div class="icon-menu">
                            <button style="color: greenyellow;" type="button"><i class="fas fa-bars"></i></button>
                        </div>
                    </nav>
                </div>
            </div>
        </div>

        <div class="header-menu-movil">
            <button class="cerrar-menu"><i class="fas fa-times"></i></button>
            <ul>
             <li><a href="#">Inicio</a></li>
             <li><a href="#productos">Productos</a></li>
             <li><a href="crear_publicacion.php">Crear Publicación</a></li>
             <li><a href="index.php">Volver a EcoRenova</a></li>
            </ul>
        </div>

        <div class="hm-banner">
            <div class="img-banner">
                <img class="bannerimg" src="https://img1.wallspic.com/crops/7/9/0/3/7/173097/173097-naturaleza-wisgoon_red_social-bosque-la_gente_en_la_naturaleza-paisaje_natural-1920x1080.jpg" alt=""> 
            </div>
            <a href=""></a>
        </div>

<section id="productos">
        <div class="hm-page-block bg-fondo">
            <div class="container">
                <div class="header-title" data-aos="fade-up">
                    <h1>Productos populares</h1>
                </div>
                <ul class="hm-tabs" data-aos="fade-up">
                    <li class="hm-tab-link" data-tab="manualidades">
                        Manualidades
                    </li>
                    <li class="hm-tab-link" data-tab="decoraciones">
                        Decoraciones
                    </li>
                    <li class="hm-tab-link" data-tab="arte">
                        Arte
                    </li>
                    <li class="hm-tab-link" data-tab="bisuteria">
                        Bisutería
                    </li>
                </ul>
                <div class="tabs-content" data-aos="fade-up">
                    <div class="grid-product">
                        <?php
                        // Conexion con la base de datos
                        $conn = conectar_bd();
                        
                        // esto obtiene la pesataña activa la pestaña activa
                        $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'bisuteria';
                        
                        // Realiza una consulta filtrada por la etiqueta
                        $sql = "SELECT * FROM publicaciones_mercado WHERE etiquetas = '$active_tab' LIMIT 4"; // Ajusta la consulta según tus necesidades
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                // Codigo para mostrar los productos xd
                                echo '<div class="product-item">';
                                echo '<div class="p-portada">';
                                echo '<a href="#">';
                                echo '<img class="imgproducto" src="data:image/jpeg;base64,' . base64_encode($row['imagen']) . '" alt="">';
                                echo '</a>';
                                echo '<span class="stin stin-new">' . htmlspecialchars($row['etiquetas']) . '</span>';
                                echo '<a href="eliminar_publicacion.php?id=' . htmlspecialchars($row['id']) . '" class="btn-eliminar" title="Eliminar">&#10006;</a>';
                                echo '</div>';
                                echo '<div class="p-info">';
                                echo '<a href="#">' . htmlspecialchars($row['titulo']) . '</h3></a>';
                                echo '<div class="precio">';
                                echo '<span>$UYU ' . htmlspecialchars($row['precio']) . '</span>';
                                echo '</div>';
                                echo '<div class="descripcion">';
                                echo '<p>' . htmlspecialchars($row['descripcion']) . '</p>';
                                echo '</div>';
                                echo '<a href="mantenimiento.html" class="hm-btn btn-primary uppercase">Contactar Vendedor</a>';
                                echo '</div>';
                                echo '</div>';
                                
                            }
                        } else {
                            echo '<p class="sinproductos">No hay productos disponibles</p>';
                        }
                        
                        
                        
                        // esto cierra  la conexión
                        mysqli_close($conn);
                        ?>
                    </div>
                </div>
            </div>
        </div>
        </section>
        <div class="foo-copy">
            <div class="container">
                <p>EcoRenova Paysandu © Todos los derechos reservados</p>
            </div>
        </div>

    </div>
    
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script src="/js/appmercado.js"></script>
</body>
</html>
