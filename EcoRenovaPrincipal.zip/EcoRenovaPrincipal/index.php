<?php
session_start();

// Verifica si el usuario inicio sesión
if (!isset($_SESSION['email'])) {
    header('Location: login_user.php'); // Redirige si no está logueado
    exit();
}
// Esto connecta con la base de datos
require 'conexion.php';
$con = conectar_bd(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>EcoRenova</title>
	<!-- CSS para cosas con Bootstrap -->
	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
   <!-- CSS fontawesome -->
	<link href="css/all.css" rel="stylesheet">
   <!-- CSS general -->
	<link href="css/style.css" rel="stylesheet">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
</head>
<body>
    <!-- Barra de Navegacion -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img class="logoimg" src="images/LogoEcoRenova.png" alt="logo" />
        </a>
            <!-- Buscador de Usuarios -->´
            <div class="buscador">
    <span id="icono-busqueda" style="cursor: pointer;">
    <div id="div-busqueda" class="div-busqueda oculto">
        <input type="text" placeholder="Buscar usuario..." id="input-busqueda">
        <span id="buscar-usuario" style="cursor: pointer;">🔍</span>
    </div>
    </span>

</div>

        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="fas fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="sobrenosotros.html">Nosotros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="mapa.html">Mapa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="indexmercado.php">EcoMarket</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Guias
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                        <a class="dropdown-item" href="guiasinicio.php">Inicio Guias</a>
                        <a class="dropdown-item" href="plasticos.html">Plasticos</a>
                        <a class="dropdown-item" href="papel_carton.html">Papel y Carton</a>
                        <a class="dropdown-item" href="vidrio.html">Vidrio</a>
                        <a class="dropdown-item" href="metales.html">Metales</a>
                        <a class="dropdown-item" href="electronicos.html">Electronicos</a>
                        <a class="dropdown-item" href="organicos.html">Organicos</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Foro
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                        <a class="dropdown-item" href="inicioforo.html">Inicio</a>
                        <a class="dropdown-item" href="foro.html">principal</a>
                    </div>
                </li>
                <!-- Nuevo menú de perfil -->
                <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span style="
            color: #00ff00; 
            background-color: green;
            border-radius: 20px; 
            padding: 0.5em 1em; 
            border: 2px solid #00ff00; 
            font-weight: bold; 
            display: inline-block; 
            text-align: center;
            font-size: 12px;
        ">
            <?php echo htmlspecialchars($_SESSION['apodo']); ?>
        </span>
    </a>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
        <a class="dropdown-item" href="verperfil.php">Ver</a>
        <form action="cerrar_sesion.php" method="post">
            <button type="submit" class="dropdown-item">Cerrar Sesión</button>
        </form>
    </div>
</li>

            </ul>
        </div>
    </div>
</nav>
</form>
                </li>
            </ul>
         </div>
      </div>
    </nav>
    <header class="slider-main">
    <div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel" data-interval="5000">
   
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
            <!-- Primera Slide -->
            <div class="carousel-item active" style="background-image: url('images/slideone.jpg')">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Bienvenido a EcoRenova Paysandú, <?php echo isset($_SESSION["apodo"]) ? htmlspecialchars($_SESSION["apodo"]) : 'Usuario'; ?>!</h3>
                    <p>Innovación ecológica para un futuro mejor.</p>
                </div>
            </div>
            <!-- Segunda Slide -->
            <div class="carousel-item" style="background-image: url('images/slidetwo.jpg')">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Bienvenido a EcoRenova Paysandú, <?php echo isset($_SESSION["apodo"]) ? htmlspecialchars($_SESSION["apodo"]) : 'Usuario'; ?>!</h3>
                    <p>Juntos por un futuro ecológico y renovable.</p>
                </div>
            </div>
            <!-- Tercera Slide -->
            <div class="carousel-item" style="background-image: url('images/slidethree.jpg')">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Bienvenido a EcoRenova Paysandú, <?php echo isset($_SESSION["apodo"]) ? htmlspecialchars($_SESSION["apodo"]) : 'Usuario'; ?>!</h3>
                    <p>Tu aliado en soluciones verdes y sostenibles.</p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</header>

    </header>
    <!-- Contenido Principal -->
    <div class="container">
        <div class="services-bar">
            <h1 class="my-4">Nuestros Servicios</h1>
            <!-- Seccion de Servicios -->
            <div class="row">
               <div class="col-lg-4 mb-4">
                  <div class="card h-100">
                     <h4 class="card-header">Mapa Interactivo</h4>
                     <div class="card-img">
                        <img class="img-fluid" style="height:270px;" src="https://www.mapasdeluruguay.eluruguayo.com/imagenes/mapas/paysandu.gif" alt="" />
                     </div>
                     <div class="card-body">
                        <p class="card-text">Aqui en EcoRenova Paysandu les bridamos un mapa interactivo en el cual podran ver ubicaciones de centros de reciclaje, tiendas de reciclaje y contenedores.</p>
                     </div>
                     <div class="card-footer">
                        <a href="mapa.html" class="btn btn-primary">Ir al Mapa</a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 mb-4">
                  <div class="card h-100">
                     <h4 class="card-header">Guias de Reciclaje</h4>
                     <div class="card-img">
                        <img class="img-fluid" style="height:270px;" src="https://www.econtenedores.com/wp-content/uploads/2024/05/guia-principiantes-instalar-estaciones-reciclaje.jpg" alt="" />
                     </div>
                     <div class="card-body">
                        <p class="card-text">En esta seccion podras encontrar guias de como recilar y que podrias hacer con cada material.</p>
                     </div>
                     <div class="card-footer">
                        <a href="guiasinicio.php" class="btn btn-primary">Ir a Guias</a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 mb-4">
                  <div class="card h-100">
                     <h4 class="card-header">EcoMarket</h4>
                     <div class="card-img">
                        <img class="img-fluid" style="height:270px;" src="https://img.freepik.com/vector-gratis/ilustracion-mercado-comida-callejera-dibujada-mano_52683-119141.jpg" alt="" />
                     </div>
                     <div class="card-body">
                        <p class="card-text">Aqui encontraras el mercado de EcoRenova Paysandu, en el puedes ver productos que te interesen y contactar directamente con el vendedor</p>
                     </div>
                     <div class="card-footer">
                        <a href="indexmercado.php" class="btn btn-primary">Ir a EcoMarket</a>
                     </div>
                  </div>
               </div>
            </div>
        </div>
        <!-- Seccion Sobre Nosotros -->
        <div class="about-main">
            <div class="row">
               <div class="col-lg-6">
                  <h2>Bienvenido a EcoRenova Paysandu</h2>
                  <p>Aquí te ayudamos a hacer de nuestro querido Paysandú un lugar más verde y sustentable. Descubre con nosotros soluciones ecológicas que se ajustan a tu vida.</p>
                  <h5 class="main-subtitle">Nuestro enfoque principal</h5>
                  <ul>
                     <li>Descubre fácilmente los puntos de reciclaje de Paysandú con nuestro mapa interactivo.</li>
                     <li>Nuestras guías prácticas te enseñarán cómo reciclar de manera eficiente y responsable. </li>
                     <li>Explora nuestro mercado en línea, donde encontrarás artículos únicos y creativos, hechos con materiales reciclados y técnicas artesanales.</li>
                     <li>Promovemos la educación y el compromiso con prácticas amigables con el medio ambiente.</li>
                     <li>Forma parte de una comunidad activa y comprometida con la protección del medio ambiente.</li>
                  </ul>
               </div>
               <div class="col-lg-6">
                  <img class="img-fluid rounded" src="images/about-img.jpg" alt="" />
               </div>
            </div>
        </div>
        <!-- Seccion de Guias de Reciclaje -->
        <div class="portfolio-main">
            <h2 class="guidestitle">Nuestras Guias</h2>
            <div class="row">
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="plasticos.html">
                           <img class="card-img-top" src="images/plasticos.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="plasticos.html">Reciclaje de Plasticos</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="papel_carton.html">
                           <img class="card-img-top" src="images/papel-carton.jpg" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="papel_carton.html">Reciclaje de Papel y Carton</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="vidrio.html">
                           <img class="card-img-top" src="images/vidrio.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="vidrio.html">Reciclaje de Vidrio</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="metales.html">
                           <img class="card-img-top" src="images/metales.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="metales.html">Reciclaje de Metales</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="electronicos.html">
                           <img class="card-img-top" src="images/electro.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="electronicos.html">Reciclaje de Electronicos</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="organicos.html">
                           <img class="card-img-top" src="images/organicos.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="organicos.html">Reciclaje de Organicos</a>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
        </div>
    </div>
      <!-- Inicio Del Footer -->
<footer class="footer">
   <div class="container bottom_border">
       <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6 col">
          <h5 class="headin5_amrc col_white_amrc pt2">Contactanos</h5>
          <!--Info y contacto -->
          <p class="mb10">Aqui puedes encontrar nuestra informacion de contacto</p>
          <p><i class="fa fa-location-arrow"></i> Leandro Gómez N°1167, entre Dr. A. de Herrera y Zorrilla de San Martín. </p>
          <p><i class="fa fa-phone"></i> +472849784 </p>
          <p><i class="fa fa fa-envelope"></i> ecorenovapaysandu01@gmail.com </p>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6 col">
          <h5 class="headin5_amrc col_white_amrc pt2">Siguenos</h5>
          <!--Redes Sociales Links-->
          <ul class="footer_ul2_amrc">
             <li>
                <a href="#"><i class="fab fa-twitter fleft padding-right"></i> </a>
                <p>Siguenos en Twitter<a href="https://x.com/eco_renova_pay/"> Aqui</a></p>
             </li>
             <li>
                <a href="#"><i class="fab fa-instagram fleft padding-right"></i> </a>
                <p>Siguenos en Instagram<a href="https://www.instagram.com/eco_renova_pay/"> Aqui</a></p>
             </li>
             <li>
                <a href="#"><i class="fab fa-facebook-f fleft padding-right"></i> </a>
                <p>Siguenos en Facebook<a href="#"> Aqui</a></p>
             </li>
          </ul>
          <!--Terminacion del Footer-->
       </div>
       <div class="col-lg-3 col-md-6 col-sm-6">
          <h5 class="headin5_amrc col_white_amrc pt2">Links Rapidos</h5>
          <ul class="footer_ul_amrc">
             <li><a href="#">Foro</a></li>
             <li><a href="#">EcoMarket</a></li>
             <li><a href="#">Mapa </a></li>
             <li><a href="#">Nosotros</a></li>
             <li><a href="#">Serivicios</a></li>
          </ul>
       </div>
       <div class="col-lg-3 col-md-6 col-sm-6 ">
          <h5 class="headin5_amrc col_white_amrc pt2">Nuestras Ultimas Guias</h5>
          <ul class="footer_ul_amrc">
             <li class="media">
                <div class="media-left">
                   <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnVUsd58IgcwR99RKzarMP1UGplfmffuPoHg&s" alt="" />
                </div>
                <div class="media-body">
                   <p>Como hacer Papel reciclado?</p>
                   <a href="papel_carton.html">ir</a>
                </div>
             </li>
             <li class="media">
                <div class="media-left">
                   <img class="img-fluid" src="images/alcancia.jpg" alt="" />
                </div>
                <div class="media-body">
                   <p>Alcancia con botellas?</p>
                   <a href="plasticos.html">ir</a>
                </div>
             </li>
             <li class="media">
                <div class="media-left">
                   <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXrkfsVJq3obQ0B_sL-Esfnnfdt_5f0pbjdQ&s" alt="" />
                </div>
                <div class="media-body">
                   <p>Costurero con Caja de huevos</p>
                   <a href="papel_carton.html">ir</a>
                </div>
             </li>
          </ul>
       </div>
    </div>
 </div>
   <div class="container">
       <div class="footer-logo">
       <a href="#"><img class="footerimg" src="images/LogoEcoRenova.png" alt="" /></a>
    </div>
       <!--Aca termina el bottom del Fotter-->
       <p class="copyright text-center">Todo los Derechos Reservados. &copy; 2024 <a href="#">EcoRenovaPaysandu</a>
       </p>
       <ul class="social_footer_ul">
       <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
       <li><a href="https://x.com/eco_renova_pay/"><i class="fab fa-twitter"></i></a></li>
       <li><a href="https://www.instagram.com/eco_renova_pay/"><i class="fab fa-instagram"></i></a></li>
       </ul>
       <!-- Aca Termina El Footer -->
   </div>
</footer>
	  
<!-- Bootstrap y JavaScripts conexiones -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/js/app.js"></script>
</body>
</html>