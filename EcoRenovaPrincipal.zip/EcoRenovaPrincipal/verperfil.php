<?php
session_start();

// Esto ve si el usuario ha iniciado sesión
if (!isset($_SESSION['email'])) {
    header('Location: login_user.php');
    exit();
}

require 'conexion.php';

// ver si estamos conectados a la base de datos
$con = conectar_bd(); 
if (!$con) {
    die("Error de conexión: " . mysqli_connect_error());
}

// esto obtiene el ID de usuario de la sesión
$id_usuario = $_SESSION['user_id'];

// Consulta para obtener los datos del usuario
$query = "SELECT nombre, 
                 (SELECT apodo FROM perfil WHERE id_user = ?) AS apodo, 
                 (SELECT biografia FROM perfil WHERE id_user = ?) AS biografia
          FROM usuario 
          WHERE id_user = ?";
$stmt = $con->prepare($query);

// Vemos si la declaracion tuvo exito
if ($stmt === false) {
    die("Error en la preparación de la declaración: " . $con->error);
}

$stmt->bind_param("iii", $id_usuario, $id_usuario, $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $nombre_usuario = $user['nombre']; 
    $apodo = $user['apodo']; 
    $biografia = $user['biografia'];
} else {
    echo "Usuario no encontrado.";
    exit();
}
$stmt->close();

// Consulta para obtener las dos publicaciones más recientes del usuario
$query_publicaciones = "
    SELECT titulo, contenido, fecha_publicacion 
    FROM foro_publicaciones 
    WHERE id_user = ? 
    ORDER BY fecha_publicacion DESC 
    LIMIT 2";
$stmt_publi = $con->prepare($query_publicaciones);

if ($stmt_publi === false) {
    die("Error en la preparación de la declaración: " . $con->error);
}

$stmt_publi->bind_param("i", $id_usuario);
$stmt_publi->execute();
$result_publi = $stmt_publi->get_result();

$publicaciones = [];
while ($row = $result_publi->fetch_assoc()) {
    $publicaciones[] = $row;
}

$stmt_publi->close();
$con->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="verperfil">
    <div class="profile-container">
        <div class="cover-photo">
            <div class="editbutton">
                <a href="index.php" class="backbutton">←</a>
                <a href="editar_perfil.php" class="editbutton">⚙️</a>
            </div>
            <div class="ambient-container"></div>
        </div>
        <div class="profile-info">
            <div class="user-details">
                <h1 class="user-name"><?php echo htmlspecialchars($nombre_usuario); ?></h1>
                <p class="user-handle">@<?php echo htmlspecialchars($apodo); ?></p>
                <p class="user-bio"><?php echo nl2br(htmlspecialchars($biografia)); ?></p>
            </div>
        </div>
        
        <div class="tweets-container">
            <?php if (count($publicaciones) > 0): ?>
                <?php foreach ($publicaciones as $publicacion): ?>
                    <div class="tweet">
                        <div class="tweet-content">
                            <h3><?php echo htmlspecialchars($publicacion['titulo']); ?></h3>
                            <p><?php echo htmlspecialchars($publicacion['contenido']); ?></p>
                            <small>Publicado el: <?php echo htmlspecialchars($publicacion['fecha_publicacion']); ?></small>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Este usuario no ha publicado nada aún.</p>
            <?php endif; ?>
        </div>
    </div>
    <script src="/js/perfil.js"></script>
</body>
</html>
