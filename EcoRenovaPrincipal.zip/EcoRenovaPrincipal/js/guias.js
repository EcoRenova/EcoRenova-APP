let currentStep = 0; // Variable para rastrear el paso actual
let activeGuide = []; // Variable para almacenar la guía activa

//Definir Cada Guia
const guides = {
  //Seccion de Guias Para Plasticos//
    guide1: [
        {
            image: "images/Materialesimg.png",
            description: "Los materiales que necesitas son: Botella de plástico (PET) vacía, tijeras o cúter, pintura acrílica o rotuladores permanentes, hilo resistente, Tierra y plantas."
        },
        {
            image: "https://mejorconsalud.as.com/wp-content/uploads/2018/05/manos-cortando-botella-plastico-pet-manualidad.jpg",
            description: "Corta la Botella: Toma una botella de plástico vacía y limpia. Con unas tijeras o cúter, corta la botella por la mitad o a 2/3 de la parte superior, dependiendo de la profundidad que desees para la maceta."
        },
        {
            image: "https://i.ytimg.com/vi/q7w3bhL0bgk/maxresdefault.jpg",
            description: "Decora la Maceta: Usa pintura acrílica o rotuladores permanentes para decorar la botella a tu gusto. Puedes hacer patrones, dibujos o simplemente pintarla de un color sólido."
        },
        {
            image: "https://live.staticflickr.com/5126/5380254344_f5cc9111e0_b.jpg",
            description: "Haz los Agujeros para Colgar: Con un objeto punzante o la punta de las tijeras, haz cuatro agujeros equidistantes cerca del borde superior de la botella cortada."
        },
        {
            image: "https://i.ytimg.com/vi/YSbPKaQvJjk/maxresdefault.jpg",
            description: "Corta y Ata la Cuerda: Corta cuatro trozos de cuerda de igual longitud y átales un nudo en cada extremo. Pasa cada cuerda por un agujero, asegurándote de que queden bien sujetas."
        },
        {
            image: "https://cl2.buscafs.com/www.qore.com/public/uploads/images/56829_1000x666.jpg",
            description: "Llena con Tierra y Planta: Rellena la maceta con tierra y planta una pequeña planta o suculenta. Asegúrate de que la planta esté bien asentada."
        },
        {
            image: "https://media.istockphoto.com/id/482020112/es/foto/alternativa-de-jardiner%C3%ADa.jpg?s=612x612&w=0&k=20&c=3tRlIhcV6K8SVff8FBzg1-1wIeTVi16PjeujHSZWPek=",
            description: "Cuelga la Maceta: Ata las cuerdas en un solo nudo en la parte superior y cuelga tu maceta en el lugar que prefieras."
        }
    ],
    guide2: [
        {
            image: "images/Materialesimg.png",
            description: "Los materiales que necesitas son: Vasos de plastico, pintura acrilica o rotuladores permanentes, pegamento caliente, base de cartòn o madera y cinta decorativa (opcional)"
        },
        {
            image: "https://media.istockphoto.com/id/870711502/photo/housewife-washing-plastic-cup.jpg?s=612x612&w=0&k=20&c=Oxwj1fPOWfc5SlbQ757fOk0UOc8X3vyJXmytMt6Rbdw=",
            description: "Limpia los Vasos: Limpia los vasos de plástico para asegurarte de que no queden restos de bebidas o alimentos."
        },
        {
          image: "https://content.instructables.com/F5Q/M4DQ/JE4KV14K/F5QM4DQJE4KV14K.png?auto=webp&fit=bounds&frame=1&height=1024&width=1024auto=webp&frame=1&height=150",
          description: "Decora los Vasos: Pinta o decora los vasos de plástico con rotuladores permanentes. Puedes usar colores sólidos, patrones o cualquier diseño que te guste."
      
        },
        {
          image: "https://www.wikihow.com/images_en/thumb/8/8d/Paint-on-Cardboard-Step-1-Version-2.jpg/550px-nowatermark-Paint-on-Cardboard-Step-1-Version-2.jpg",
          description: "Prepara la Base: Toma una base de cartón o madera y pinta o decora también si lo deseas."
        },
        {
          image: "https://files.oaiusercontent.com/file-ajSMRFHNTrOSk1hE83v5iK5A?se=2024-10-03T10%3A56%3A54Z&sp=r&sv=2024-08-04&sr=b&rscc=max-age%3D604800%2C%20immutable%2C%20private&rscd=attachment%3B%20filename%3D0c6c52ac-cefb-48a7-b7ff-4d6ff46f9a31.webp&sig=x47MRtMaIUzqEG2arpfphQ8MbwI/Pgvz3%2BZ2qTtnDVQ%3D",
          description: "Pega los Vasos: Usando pegamento caliente, pega los vasos de plástico en la base en la disposición que prefieras. Puedes colocarlos en fila, en círculo, o de forma escalonada."
        },
        {
          image: "https://i.pinimg.com/736x/fa/ce/a6/facea663008f26287b13734fbd483375.jpg",
          description: "Usa el Organizador: Coloca lápices, bolígrafos, tijeras y otros artículos de papelería en los vasos. Ahora tienes un organizador de escritorio personalizado."
        },
        
    ],
    guide3: [
      {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Botella de plastico, tijeras o cuter, Pintura acrilica o en spay, Pinceles, fieltro o cartulina."
      },
      {
          image: "https://cms.mcclabel.com/wp-content/uploads/2023/05/Close_up_Peel-1-scaled.jpg",
          description: "Preparación de la Botella: Limpia bien la botella de plástico y quita cualquier etiqueta. Asegúrate de que esté completamente seca antes de comenzar."
      },
      {
        image: "https://media.homify.com/p/diy/photos/9acef5bc-7b6e-4a8a-8438-34aa1496704e.jpg",
        description: "Cortar la Ranura:Usa un cúter o tijeras para cortar una ranura en la parte superior de la botella. La ranura debe ser lo suficientemente larga y ancha para que las monedas pasen fácilmente, pero no tan grande como para que las monedas se caigan"
    
      },
      {
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS39IXpeUqEQS5CBz5V1G7RfC_8F9eLc48oww&s",
        description: "Pintar la Botella: Pinta toda la botella con pintura acrílica o en spray del color que hayas elegido para tu cerdito, como rosa. Aplica varias capas si es necesario y deja secar completamente."
      },
      {
        image: "https://images.homify.com/image/upload/v1628127154/p/diy/photos/obtzmevn0vdyvodopede.jpg",
        description: "Crear las Orejas: Corta dos triángulos de fieltro o cartulina para hacer las orejas del cerdito. Pégalos en la parte superior de la botella, cerca del tapón, usando pegamento fuerte."
      },
      {
        image: "https://static4.todobonito.com/m/2019/01/orejas-morritos-cerdo_08-568x400.jpg",
        description: "Hacer la Nariz: Usa el tapón de la botella como la nariz del cerdito. Puedes pintarlo del mismo color que la botella o dejarlo del color original. Dibuja dos círculos pequeños con un rotulador permanente para hacer los orificios de la nariz."
      },
      {
        image: "https://images.hive.blog/0x0/https://i.postimg.cc/D0tdJGmZ/20210406-154104-mfnr.jpg",
        description: "Crear las Patas: Corta cuatro pequeñas piezas de fieltro o cartulina para hacer las patas, tambien puedes usar tapas si quieres. Pégalos en la parte inferior de la botella, asegurándote de que estén bien alineados para que la hucha se mantenga de pie."
      },
      {
        image:"https://i.pinimg.com/236x/6d/d8/cf/6dd8cf619813ba48f409eddbd10c8464.jpg",
        description:"Añadir los Ojos: Pega los ojos móviles en la parte frontal de la botella, justo encima de la nariz. Si no tienes ojos móviles, puedes dibujarlos con un rotulador permanente."
      },
      {
        image: "https://i.pinimg.com/564x/58/6c/43/586c43a6bb437d27d8ab6cf2b816f372.jpg",
        description:"Añadir la Cola: Por ultimo corta un pequeño trozo de fieltro o cartulina en forma de espiral para crear la cola del cerdito. Pega la cola en la parte trasera de la botella.",
      }
      
  ],
  guide4: [
    {
        image: "images/Materialesimg.png",
        description: "Los materiales que necesitas son: Envases de yogur o botellas de plastico pequeñas, pintura acrilica o rotuladores permanentes, tijeras o cuter, pegamento fuerte, cartulina o fieltro, ojos moviles (opcional)."
    },
    {
        image: "https://medioambienteenaccion.com.ar/download/multimedia.normal.8c392a6915681355.616775612d677269666f5f6e6f726d616c2e6a7067.jpg",
        description: "Limpia los envases: Lava bien los envases de yogur o botellas pequeñas para asegurarte de que no quede ningún residuo."
    },
    {
      image: "https://i.ebayimg.com/images/g/3zUAAOSwEOJj~nOf/s-l1200.jpg",
      description: "Decora los envases: Pinta los envases con colores brillantes y divertidos, usando pintura acrílica o rotuladores. Puedes hacer caras de animales, personajes o figuras abstractas."
  
    },
    {
      image: "https://i.pinimg.com/originals/17/ff/a4/17ffa4e1039ccbd4d4c3bbe2162c832e.jpg",
      description: "Añade Detalles: Con fieltro o cartulina, corta pequeñas formas para hacer orejas, patas, alas o cualquier detalle adicional que desees añadir a tus personajes. Pégalos en su lugar con pegamento fuerte."
    },
    {
      image: "https://dilipa.com.ec/1614-large_default/ojitos-movil-28mm-paqx8-j-009.jpg",
      description: "Ojos Móviles: Si tienes ojos móviles, pégalos en la parte superior de los envases para darles más vida a los juguetes. Si no, puedes dibujar los ojos con rotuladores permanentes."
    },
    {
      image: "https://assets.saposyprincesas.com/2020/05/botellas-bolos-sumo.jpg",
      description: "Listo, tendras un juguete para tus niños y ayudaras al medioambiente a la vez."
    },  
],
guide5: [
  {
      image: "images/Materialesimg.png",
      description: "Los materiales que necesitas son: Botellas de plastico, tijeras o cuter, pintura acrilica o en spary, pinceles, pegamento fuerte, alambre o palitos de madera, rotuladores permanentes (opcional), purpurina, cuentas o adornos (opcional)"
  },
  {
      image: "https://www.periodicovictoria.cu/wp-content/uploads/2017/07/Rellenar-agua.jpg",
      description: "Limpia las Botellas: Asegúrate de que las botellas estén completamente limpias y secas antes de comenzar. Elimina las etiquetas y cualquier residuo."
  },
  {
    image: "https://www.wikihow.com/images/thumb/e/e4/Make-a-Vase-out-of-a-Plastic-Bottle-Step-3-Version-2.jpg/550px-nowatermark-Make-a-Vase-out-of-a-Plastic-Bottle-Step-3-Version-2.jpg",
    description: "Corta la Parte Superior de la Botella: Con un cúter o unas tijeras, corta la parte superior de la botella. Esta será la base de la flor, donde formaremos los pétalos. Dependiendo de la flor que quieras crear, puedes usar más o menos parte de la botella."

  },
  {
    image: "https://t1.uc.ltmcdn.com/es/posts/2/9/0/como_hacer_una_flor_con_una_botella_de_plastico_1092_paso_4_600.jpg",
    description: "Forma los Pétalos:Corta el borde superior de la botella en tiras verticales, creando pétalos. Puedes hacerlos más anchos o más delgados según prefieras."
  },
  {
    image: "https://t2.uc.ltmcdn.com/es/posts/2/9/0/como_hacer_una_flor_con_una_botella_de_plastico_1092_paso_7_600.jpg",
    description: "Decora los Pétalos: Pinta los pétalos con pintura acrílica o en spray. Puedes usar un solo color o combinar varios para crear un efecto más llamativo."
  },
  {
    image: "https://assets.saposyprincesas.com/2020/05/botellas-bolos-sumo.jpg",
    description: "Listo, tendras un juguete para tus niños y ayudaras al medioambiente a la vez."
  }
],
      //Termina la session Plasticos//

      //Seccion de Guias Para Papel y Carton//
guide6: [
    {
        image: "images/Materialesimg.png",
        description: "Los materiales que necesitas son: Papel usado, agua, tijeras, recipientes grandes, batidora o licuadora, una malla, telas viejas, una esponja y algo para usar como peso."
    },
    {
        image: "https://believeinart.org/wp-content/uploads/trozos-de-papel-copia-1080x675.jpg",
        description: "Cortar papel: Comienza cortando todo el papel en trozos pequeños con las tijeras."
    },
    {
      image: "https://i.pinimg.com/474x/78/6d/c9/786dc930f296b81cd2449e036cb2988c.jpg",
      description: "Remojar el papel: Deja caer los trozos en el recipiente y añade el doble de agua caliente que de papel. Dejalos remojar unos 20 minutos"
      
    },
    {
      image: "https://mimundosustentable.com/wp-content/uploads/2020/06/licuadora-con-pulpa-de-papel.jpg",
      description: "Triturar el papel: Mezcla todo bien y trituralo con la batidora para conseguir una pasta."
    },
    {
      image: "https://misionescuatro.com/wp-content/uploads/2022/03/como-hacer-papel-artesanal-813x458.jpg",
      description: "Visualizar el tamaño: Extiende la pasta de papel en una malla con la ayuda de una cuchara o de un rodillo y darle el tamaño que queramos."
    },
    {
      image: "https://www.diariodequeretaro.com.mx/incoming/qxzxtq-papel-1.jpg/ALTERNATES/LANDSCAPE_1140/Papel%201.jpg",
      description: "Dejar secar el papel: Saca el papel del molde, ponlo en una tela seca y cubrela con otra, Se puede poner un peso para evitar que quede ondulado."
    },
    {
      image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLPUM_QdGmGrjCTFKp4H1_PwUqUKaKbY5-rg&s",
      description:"Finalizar el proceso: Luego de que el papel seque, ya estara listo para usar como tu prefieras! ",
    }
   ],
   guide7: [
    {
        image: "images/Materialesimg.png",
        description: "Los materiales que necesitas son: Maples de huevos, pasta de papel machè, pinturam tijeras, cinta adhesiva, plastico o bolsa de plastico, tijeras y por ultimos flores o plantas."
    },
    {
        image: "https://i.ytimg.com/vi/AGhptCRdZxQ/mqdefault.jpg",
        description: "Preparar la base: Corta la bandeja de cartón de huevos en secciones que tengan la forma deseada para tus macetas. "
    },
    {
      image: "https://www.minutoneuquen.com/u/fotografias/m/2024/4/30/f768x1-667281_667408_5050.png",
      description: "Forma la maceta: Usa varias secciones de cartón para crear la forma de la maceta. Puedes unirlas con cinta adhesiva para darles estabilidad."
      
    },
    {
      image: "https://www.jovi.es/image/get/934/-/productos--SEP--39e9112d9b60c899bbd169d1d8cf3829-jpg/_19_-jpg",
      description: "Aplicar Pasta de Papel Maché: Mezcla la pasta de papel maché y aplícala sobre la estructura de cartón. Asegúrate de cubrir bien todas las áreas y dejar secar completamente."
    },
    {
      image: "https://media.istockphoto.com/id/1126308250/es/foto/mano-pintura-pastel-rosa-color-peque%C3%B1a-jardinera-hormig%C3%B3n-con-pincel-verde.jpg?s=612x612&w=0&k=20&c=trAeAdbjMYCobIDxf8tqX9P0VsX8xERZAf_j3CFzs-s=",
      description: "Pintar (opcional): Si deseas, pinta el exterior de la maceta con los colores que prefieras. Deja secar."
    },
    {
      image: "https://i.pinimg.com/236x/4d/74/7e/4d747e6c98a505e1eaf8a47f6aa97781.jpg",
      description: "Agregar Tierra y Plantas: Llena la maceta con tierra y planta tus flores o plantas favoritas.."
    },
    {
      image:"https://i.blogs.es/290cd1/huevos-macetas-1/450_1000.jpg",
      description:"Decoración Final: Puedes añadir elementos decorativos como piedras, musgo o cintas alrededor de la maceta.",
    }
   ],
   guide8: [
    {
        image: "images/Materialesimg.png",
        description: "Los materiales que necesitas son: Una caja de huevos, hilos y pintura."
    },
    {
        image: "https://media.istockphoto.com/id/511799104/es/foto/pinceles-pintura-y-cart%C3%B3n-de-huevos.jpg?s=612x612&w=0&k=20&c=thw6OiGx07hxOKu2rPxCjZrg9tzAmtZ-7xR5SdgKCoc=",
        description: "Pinta la caja: Agarra la caja de huevos y pintala a tu antojo."
    },
    {
      image: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgQtVMy35hU6kYE2GcWuXXyL0RwK6dmQqsxTtXbbBU2I5h-0kkkrAesTp-q_XzPtO6R28s0zswOTbuG4nGs49YTQLwgulEfgcWgXqnGvikus-OoX9naeV0nYWfYKOtgxIi4GPott0V4GU0/s1600/costurero+1.jpg",
      description: "Rellena la caja: Ahora debes rellenar las cajas con tus herramientas de costura y estara lista para usar."
      
    }
   ],
   guide9: [
    {
        image: "images/Materialesimg.png",
        description: "Los materiales que necesitas son: Cajas de carton, pintura, papeles de decoracion con diseños y pegamento o cinta."
    },
    {
        image: "https://marpack.com.mx/img/caja-regular02.png",
        description: "Consigue los materiales: Reúne poco a poco cajas de diferentes tamaños. Aquí las cajas de infusiones te vendrán muy bien y también las cajas de galletas."
    },
    {
      image: "https://m.media-amazon.com/images/I/511IoJuR1cL.jpg",
      description: "Estructura y Decoracion: Toma medidas de tus cajones y comienza a recortarlas, customizarlas y pegarlas hasta que tengas un organizador de cajones 100% reciclado que, no solo quedará genial sino que te ayudará a encontrar todo de un vistazo."
      
    },
    {
      image: "https://i.pinimg.com/474x/db/c8/ea/dbc8ea86001c0a1fb212e1c87e6f283f.jpg",
      description: "Finalizado de la caja: Puedes usarlo donde quieras, ya sea en los cajones de la cocina, del baño o del dormitorio."
      
    }
   ],
   guide10: [
    {
        image: "images/Materialesimg.png",
        description: "Los materiales que necesitas son: Caja de zapatos, Cartones de los rollos de papel de cocina, tijeras o trincheta, pegamento o silicona caliente, pintura y rotuladores, lapices, boligrafos, etc."
    },
    {
        image: "https://images.homify.com/image/upload/v1542271984/p/diy/photos/v3grw0fnvy5v2pwfnxzq.jpg",
        description: "Prepara la base: Toma la caja de zapatos y decide si quieres usar la tapa como base o desecharla. Si la caja es muy alta, puedes cortarla para reducir la altura según el tamaño de tus rollos de papel."
    },
    {
      image: "https://live.staticflickr.com/2441/5843455745_3d77f328b6_b.jpg",
      description: "Corta los rollos de papel: Si los rollos de papel son más altos de lo que te gustaría, usa unas tijeras o un cúter para cortarlos a la altura deseada. Puedes hacerlos todos iguales o de diferentes alturas, según prefieras."
      
    },
    {
      image: "https://www.tuhogar.com/content/dam/cp-sites/home-care/tu-hogar/global/estilo-de-vida/tendencias-en-el-hogar/manualidades-navidenas-para-ninos-arbol-de-tubos-de-carton/pintararbol.jpg",
      description: "Pinta o decora la caja y los rollos: Decora la caja de zapatos y los rollos de papel. Puedes usar pintura, papel de colores, o cinta adhesiva decorativa. Asegúrate de dejar secar bien antes de continuar."
      
    },
    {
      image: "https://i.ebayimg.com/thumbs/images/g/3jMAAOSwvFVm611y/s-l1200.jpg",
      description: "Coloca los rollos dentro de la caja: Una vez decorados, pega los rollos dentro de la caja de zapatos con pegamento o silicona caliente. Distribúyelos de manera que queden firmes y ocupen todo el espacio de la caja. Puedes colocarlos en filas o formando un patrón circular."
      
    },
    {
      image: "https://i.pinimg.com/originals/92/df/b8/92dfb8c1aab8cde986a5f1fa2dbbfe34.jpg",
      description: "Llena tu portalápices: Una vez seco, ya puedes empezar a llenar cada uno de los rollos con tus lápices, bolígrafos, rotuladores, y cualquier otro material que desees organizar."
      
    }
   ],   //Termina la session Papel y Carton//

        //Seccion de Guias Para Electrnicos//  
    guide11: [
      {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: CDs o DVDs sobrantes, carton, el pegamento del que dispongas, papeles con diseños, pintura."
      },
      {
          image: "https://www.wikihow.com/images_en/thumb/f/fd/Cut-a-Circle-Out-of-Cardboard-Step-8-Version-3.jpg/550px-nowatermark-Cut-a-Circle-Out-of-Cardboard-Step-8-Version-3.jpg",
          description: "Dibuja el contorno del disco sobre cartulina, cartón fino o fieltro. Recorta dos círculos por cada posavasos para cubrir el agujero central."
      },
      {
        image: "https://t1.uc.ltmcdn.com/es/posts/2/4/0/como_hacer_posavasos_con_cds_26042_paso_3_600.webp",
        description: "Pega los círculos de cartulina en ambos lados del CD usando cola de contacto, extendiéndola con un pincel.",
      },
      {
        image: "https://scontent.fmvd3-1.fna.fbcdn.net/v/t39.30808-6/461173584_2227992307573705_2576155132486023135_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=833d8c&_nc_ohc=d7Q5BURkdX0Q7kNvgFdHGd8&_nc_zt=23&_nc_ht=scontent.fmvd3-1.fna&_nc_gid=Ad7ce99TIuRSMN6XQT-GDw4&oh=00_AYC_j8tpQEOeHafv9K6ATOBZZxztP27ob4gG-9HaYjkIKg&oe=671D800B",
        description: "Corta círculos de tela del mismo tamaño que el CD, y pégalos como forro y decoración. Luego de esto los tendras listos para usar.",
      }
    
    
    ], 
    guide12: [
      {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Discos DVD, espejo pequeño, pegamento, tijeras o cortador."
      },
      {
          image: "https://e1.pngegg.com/pngimages/462/206/png-clipart-prismatic-s-broken-compact-disc-thumbnail.png",
          description: "Recorta los discos: Corta los discos en piezas pequeñas (triángulos o cuadrados)."
      },
      {
        image: "https://cdn.shopify.com/s/files/1/0282/4414/8333/files/14_Upcycling_Crafts-min.jpg?v=1661800020",
        description: "Pega las piezas alrededor de un espejo pequeño, creando un marco brillante y colorido.",
      }  
    ], 
    guide13: [
      {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Placas de circuito, anillas de llavero, cadena (opcional), papel de lijar, tijeras o cortadores  y un taladro (opcional)."
      },
      {
          image: "https://jamindopcba.com/wp-content/uploads/2024/01/How-to-clean-PCB-board-dirt-and-other-materials-manually-1.jpeg",
          description: "Reúne y limpia las placas de circuito."
      },
      {
        image: "https://cactustronica.com/wp-content/uploads/2021/04/LIMPIEZA-DE-TARJETA-PCB-VIRGEN-CON-ALCOHOL-ISOPROPILICO.jpg",
        description: "Lija los bordes para quitar partes afiladas.",
      },
      {
        image: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj8zdZiVdi61D1uW84xj1QrJTqYnXVMOgNHjNADta-PBf9IMEjO1Upl6HLX6P13R4FrsiMqxOP79xfEuGlbOBcgmSS5dofpFOxwOEPpmJK47SBahW1ECOEXv2WzMqzoQqJCs7DGMTWhsVM_/s1600/P8040037.JPG",
        description: "Haz agujeros en las placas (si no tienen).",
      }, 
      {
        image: "https://i.pinimg.com/736x/f2/51/ab/f251ab5de80261061f10155e4ccb87a1.jpg",
        description: "Conecta las placas a las anillas de llavero.",
      }   
    ],
    guide14: [
      {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son:Disquete, tierra para macetas plantas y Grava (opcional)."
      },
      {
          image: "https://img.freepik.com/vector-premium/lindo-personaje-disquete-como-mascota-servicios-limpieza-lindo-diseno_152558-48607.jpg",
          description: "Preparar el Disquete: Limpia y si deseas, corta la parte superior."
      },
      {
        image: "https://www.ecologistasenaccion.org/wp-content/uploads/2021/06/manos-tierra.jpg",
        description: "Llenar con Tierra: Agrega tierra hasta 2/3 de la capacidad.",
      }, 
      {
        image: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhuPezSasyyeZTtZy3R7iLWre_cCVkvhyphenhyphenTKQWsrXRlMxpgHODh_xCvWdYEJqBQMRu1pdilIYegV4hCRnY7rKkEAm4pKGtu48ptSDloD5dybh_1HtPHG1Dovsdz6daPywWgwDsHK8Ja79_g/s1600/Portamaceta-diskette.jpg",
        description: "Plantar: Coloca la planta y cubre las raíces con tierra.",
      },
      {
        image: "https://i.pinimg.com/originals/c3/61/70/c3617035777f811ca5bf75bc65ed68fe.jpg",
        description: "Decorar: Añade grava en la parte superior (opcional).",
      }
    ],
    guide15: [
      {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son:Teclas de teclado viejas, un marco de fotos, pegamento fuerte y pintura o spary oara decorar (opcional)."
      },
      {
          image: "https://us.123rf.com/450wm/tr3gi/tr3gi1006/tr3gi100600022/7258409-close-up-en-una-pila-de-teclas-del-teclado-de-ordenador-negro.jpg?ver=6",
          description: "Reúne las teclas: Desmonta las teclas de los teclados viejos. Puedes usar un destornillador pequeño o simplemente tirarlas con cuidado."
      },
      {
        image: "https://i.pinimg.com/736x/e7/8e/29/e78e29efe84af28ad5a90c0808e51684.jpg",
        description: "Prepara el marco: Si usas un marco de cartón o madera, asegúrate de que esté limpio y seco. Si deseas, puedes pintarlo del color que prefieras.",
      }, 
      {
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwQ4frgQxJEfAfvxzgfN20klm7qWz_auLUmBJuu8LOvR_ABb69WIeIblkFIKQcwxJfLrs&usqp=CAU",
        description: "Pega las teclas: Comienza a pegar las teclas en el marco, una por una. Aplica una pequeña cantidad de pegamento en la parte posterior de cada tecla y presiónala firmemente en su lugar. Asegúrate de dejar espacio para la foto en el centro.",
      },
      {
        image: "https://i.etsystatic.com/13068892/r/il/dddfa7/1471786352/il_570xN.1471786352_7gx2.jpg",
        description: "Inserta la foto: Una vez que el pegamento esté seco, coloca la foto que deseas mostrar en el marco.",
      }
    ],   //Termina la session Electronicos//

         //Seccion de Guias Para Vidrios//
      
     guide16: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Botellas de vidrio, cuerda resistente o alambre, tierra, plantas, un taladro y una lija."
        },
        {
          image: "https://cloudfront-us-east-1.images.arcpublishing.com/radiomitre/XBNNSF77GRBJZCIYTYZVEIIV6M.jpg",
          description: "Limpia bien la botella y retira cualquier etiqueta."
        },
        {
          image: "https://i.ytimg.com/vi/wUH63j8JBbE/maxresdefault.jpg",
          description: "Corta la botella por la mitad o en el tamaño deseado. Puedes usar un cortador de vidrio o una cuerda empapada en alcohol, quemada con un encendedor y luego sumergida en agua fría (con cuidado).",
        },
        {
          image: "https://www.purplant.es/wp-content/uploads/2024/02/terrarios-botella-819x1024.jpg",
          description: "Llena la botella con un poco de tierra y coloca la planta dentro.",
        },
        {
          image: "https://i.pinimg.com/564x/e9/7d/c8/e97dc81015bd6d29da342218d137ebdd.jpg",
          description: "Ata la cuerda o el alambre alrededor de la boca de la botella para colgarla donde prefieras.",
        }
      ],
      guide17: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Frascos de vidrio, pintura, cinta adhesiva y velas pequeñas. "
        },
        {
          image: "https://www.cocinadelirante.com/sites/default/files/images/2023/03/trucosparalimpiarfrascos.jpg",
          description: "Limpia el frasco y retira las etiquetas."
        },
        {
          image: "https://cdn0.casamientos.com.ar/article/7698/original/1280/jpg/8967-06.jpeg",
          description: "Usa cinta o plantillas para crear diseños en el exterior del frasco (puedes hacer rayas, corazones o cualquier forma).",
        },
        {
          image: "https://i.ytimg.com/vi/fQ81eCk9O18/maxresdefault.jpg",
          description: "Pinta el frasco con el spray o pintura para vidrio y deja secar, luego la cinta para revelar el diseño",
        },
        {
          image: "https://st3.depositphotos.com/4076647/13060/i/380/depositphotos_130603256-stock-photo-glass-jars-with-lit-candles.jpg",
          description: "Coloca una vela dentro y disfruta del portavelas decorativo.",
        }
      ],
      guide18: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Botella de vidiro, luces led de tira o una vela de led, perforadora de vidrio (opcional) y un cable con interruptor (opcional). "
        },
        {
          image: "https://cloudfront-us-east-1.images.arcpublishing.com/radiomitre/XBNNSF77GRBJZCIYTYZVEIIV6M.jpg",
          description: "Limpia la botella y retira las etiquetas."
        },
        {
          image: "https://i.ytimg.com/vi/ru7xELCn9tQ/maxresdefault.jpg",
          description: "Si tienes una perforadora de vidrio, haz un pequeño agujero en la parte inferior para pasar el cable de las luces LED.",
        },
        {
          image: "https://t1.uc.ltmcdn.com/es/posts/8/5/3/como_hacer_una_lampara_con_botellas_42358_paso_6_600.jpg",
          description: "Inserta la cuerda de luces LED dentro de la botella (si no puedes hacer un agujero, simplemente mete las luces desde la parte superior)",
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo9MPoTxLRfUO3WoC8HijwBmHK5Ypv2tjS9pju65oUGmHE_MNHitZ1rVty0hLAsxf4ELY&usqp=CAU",
          description: "Coloca la botella en una base o rincón y enchufa las luces para una lámpara única y decorativa.",
        }
      ],
      guide19: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Fragmentos de vidrio de colores (vidrio de botellas, frascis, etc.), pegamento o silicona transparente y un marco de fotos. "
        },
        {
          image: "https://m.media-amazon.com/images/I/61xzQOesOHL._AC_UF894,1000_QL80_.jpg",
          description: "Coloca los fragmentos de vidrio sobre la base o marco de fotos para crear un diseño, como flores, paisajes o patrones abstractos."
        },
        {
          image: "https://i.etsystatic.com/45870764/r/il/a448a3/5548820264/il_fullxfull.5548820264_191o.jpg",
          description: "Usa pegamento o silicona para fijar los trozos de vidrio a la superficie.",
        },
        {
          image: "https://i.pinimg.com/236x/ce/f1/64/cef16431ae69cc5ecfb622992a74f944.jpg",
          description: "Deja secar y coloca el cuadro en un lugar donde la luz lo ilumine para que resalten los colores.",
        }
      ],
      guide20: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Botellas o frascos de vidrio, piedras pequeñas y arena, tierra y plantas. "
        },
        {
          image: "https://www.cocinadelirante.com/sites/default/files/images/2023/03/trucosparalimpiarfrascos.jpg",
          description: "Limpia bien la botella o frasco de vidrio."
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnrtEm1TeUADdHWsj5I-9HAHzZNTkLlBwhHQ&s",
          description: "Llena el fondo con una capa de piedras para el drenaje.",
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRF9j83PKWudRjFF9Z4MMcu0PLTWCemR211Ww&s",
          description: "Agrega un poco de arena y después tierra.",
        },
        {
          image: "https://ecoinventos.com/wp-content/uploads/2020/01/terrario-eterno-diy.jpg",
          description: "Planta dentro del frasco y añade un poco más de arena en la superficie para darle un acabado.",
        }
      ],     //Termina la session Vidrios//

             //Seccion de Guias Para Metales//
      guide21: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Latas de aluminio, pintura, martillo y clavos, vela pequeña o luz LED. "
        },
        {
          image: "https://static.wixstatic.com/media/359f8b_83f5431321d74e75aa29e0b4a0366d16~mv2.jpg/v1/fill/w_560,h_374,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/359f8b_83f5431321d74e75aa29e0b4a0366d16~mv2.jpg",
          description: "Lava y seca bien la lata."
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7qAPhRzvctHoV19gs6f3Ew0b5PH9VRy1_nw&s",
          description: "Marca con un rotulador el diseño que quieres (como estrellas, corazones o patrones geométricos).",
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYPEHDwxdyjUbe34dU5GOLVW92rEGBpXIt6A&s",
          description: "Usa un clavo y un martillo para hacer agujeros en las marcas, creando el diseño en el metal.",
        },
        {
          image: "https://scouts.es/wp-content/uploads/2014/03/lampara.jpg",
          description: "Coloca una vela pequeña dentro y disfruta del patrón de luz que crea en la habitación.",
        }
      ],
      guide22: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Latas de aluminio, pintura, tierra y plantas. "
        },
        {
          image: "https://static.wixstatic.com/media/359f8b_83f5431321d74e75aa29e0b4a0366d16~mv2.jpg/v1/fill/w_560,h_374,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/359f8b_83f5431321d74e75aa29e0b4a0366d16~mv2.jpg",
          description: "Lava y seca bien la lata."
        },
        {
          image: "https://www.wikihow.com/images_en/thumb/6/6a/Make-a-Play-Telephone-Step-3-Version-4.jpg/550px-nowatermark-Make-a-Play-Telephone-Step-3-Version-4.jpg",
          description: "Haz agujeros en la parte inferior de la lata para el drenaje.",
        },
        {
          image: "https://i.ytimg.com/vi/WycWme2HW6k/sddefault.jpg?sqp=-oaymwEmCIAFEOAD8quKqQMa8AEB-AH-DoACuAiKAgwIABABGHIgXSg8MA8=&rs=AOn4CLAQyXuYvL56BsVIk19bdRIHuWUNSA",
          description: "Decora la lata pintándola a tu gusto y deja secar.",
        },
        {
          image: "https://media.admagazine.com/photos/618a608090c4ec9a52ca0e7a/4:3/w_2000,h_1500,c_limit/85595.jpg",
          description: "Llena la lata con tierra y planta la planta que desees.",
        }
      ], 
      guide23: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Latas de pintura, tornillos y destornillador, pintura (opcional)."
        },
        {
          image: "https://acdn.mitiendanube.com/stores/275/838/products/envase-lata-metal-1-48b709d538501e976f17151063346061-1024-1024.jpg",
          description: "Lava bien las latas y retira cualquier resto de etiquetas o pintura."
        },
        {
          image: "https://artesaniachopo.com/wp-content/uploads/2020/10/Reciclando-latas-con-pintura-Multisurface-y-Chalky-de-DecoArt-9-1024x682.jpg",
          description: "Pinta las latas para que combinen con tu decoración.",
        },
        {
          image: "https://i.pinimg.com/474x/c7/0d/95/c70d95c655dd6093e532d8f2b496f4cc.jpg",
          description: "Atornilla las latas a la pared en diferentes alturas o en forma de estante, con la abertura hacia afuera.",
        }
      ], 
      guide24: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Latas pequeñas de distintos tamaños, pintura y pegamento."
        },
        {
          image: "https://i.ytimg.com/vi/mJG_c-jJl9k/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLCiKW_LQuqnN5mhJ5ly2IzIIGSZLQ",
          description: "Lava las latas y asegúrate de que estén secas."
        },
        {
          image: "https://i.pinimg.com/736x/37/a5/d4/37a5d4fbb3c5133450017ecf20e6b567.jpg",
          description: "Decora las latas con pintura o cinta adhesiva decorativa para darles un toque personalizado.",
        },
        {
          image: "https://i.pinimg.com/736x/ac/95/a4/ac95a41d63710f5f56b5df3fd98796b3.jpg",
          description: "Usa pegamento fuerte o silicona para unir las latas entre sí en una estructura estable.",
        }
      ],
      guide25: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Utensillos de cocina viejos de metal, tabla de madera, tornillos y destornillador y un taladro."
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrMfMh6OpnskLZ4ZwXnpEKIjSHhIt3FBrFtw&s",
          description: "Limpia bien los utensilios y la tabla de madera."
        },
        {
          image: "https://st.depositphotos.com/1050267/4155/i/950/depositphotos_41551397-stock-photo-bent-fork.jpg",
          description: "Dobla los utensilios ligeramente hacia arriba para que sirvan como colgadores.",
        },
        {
          image: "https://http2.mlstatic.com/D_NQ_NP_570711-MLU20610543423_032016-O.webp",
          description: "Atornilla los utensilios a la tabla de madera, dejando un espacio entre cada uno para colgar cosas.",
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrKeg1hHepCnWNIzinYTUjdEpbhP4vIfXrcw&s",
          description: "Fija la tabla en la pared y úsala como perchero para colgar llaves, toallas, o accesorios decorativos.",
        }
      ],    //Termina la session Metales//

            //Seccion de Guias Para Organicos//
      guide26: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Restos organicos, tierra, contenedor (puede ser una caja de madera o una cubeta grande), palo o pala para mezclar."
        },
        {
          image: "https://s1.elespanol.com/2019/09/19/como/jardineria-dinero-como_hacer_430467023_134446284_1706x960.jpg",
          description: "Coloca una capa de tierra en el fondo del contenedor."
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4CQu4VFCjampdmvBqFUxKlIeH1CVCseGT8Q&s",
          description: "Añade los restos orgánicos, alternando con capas de tierra.",
        },
        {
          image: "https://media.istockphoto.com/id/1334243681/es/foto/caja-de-compost-al-aire-libre-llena-de-marrones-y-verduras-de-jard%C3%ADn-y-desechos-de-alimentos.jpg?s=612x612&w=0&k=20&c=GQYnKdhOwS8_5Aam3NGa8JMrfqk2rcoqIe7IzL_riaw=",
          description: "Mezcla el contenido regularmente y manténlo húmedo (pero no empapado).",
        },
        {
          image: "https://www.ecolatras.es/archivos/varios/1686816393.jpg",
          description: "Después de unas semanas, el compost estará listo para usar en el jardín como abono natural.",
        }
      ],
      guide27: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son: Posos de café usados (bien secos), aceite de coco o aceite de oliva, azúcar (opcional) y un frasco de vidrio para almacenar."
        },
        {
          image: "https://www.semana.com/resizer/v2/UBNNMSLFL5EUBEIXZNSKU5KZYU.jpg?auth=22ae1713c77bbc32a92c5cf0e4fba4c85865bd440b69706ab7ee7787bde45ce0&smart=true&quality=75&width=1280&height=720",
          description: "Mezcla los posos de café con el aceite de coco u oliva en partes iguales hasta obtener una pasta."
        },
        {
          image: "https://s1.elespanol.com/2015/09/21/cocinillas/cocinillas_65753431_116212147_1024x576.jpg",
          description: "Añade azúcar si quieres un exfoliante más abrasivo.",
        },
        {
          image: "https://michelle-organic.com/wp-content/uploads/IMG_3307-Photoroom-430x430.jpg",
          description: "Guarda la mezcla en un frasco de vidrio con tapa.",
        }
      ],
      guide28: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son:Cáscaras de naranja, limón o lima, vinagre blanco, frasco de vidrio con tapa y una botella con rociador."
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSn21rQ4waQl1bfLmhI0y0T0S-WmgLcez2bA&s",
          description: "Coloca las cáscaras de cítricos en un frasco y cúbrelas con vinagre."
        },
        {
          image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4FOcL6Qnetwl9jY6mvX-ywq2BtqOes4LC2k_O_YjxpGRx6aOyn2KmLLxkRJSM_qNxfzw&usqp=CAU",
          description: "Deja reposar la mezcla por unas 2 semanas en un lugar oscuro.",
        },
        {
          image: "https://www.cuerpomente.com/medio/2021/02/17/vinagre-limon-cocina_0b0cd249_1200x1200.jpg",
          description: "Cuela la mezcla y transfiere el líquido a una botella con rociador.",
        }
      ],
      guide29: [
        {
          image: "images/Materialesimg.png",
          description: "Los materiales que necesitas son:Cáscaras de huevo (en mitades), tierra para plantar y semillas de hierbas o flores pequeñas."
        },
        {
          image: "https://www.cualestuhuella.cl/files/626828f7b121e_890x533.webp",
          description: "Limpia cuidadosamente las cáscaras de huevo y déjalas secar."
        },
        {
          image: "https://t1.uc.ltmcdn.com/es/posts/8/7/4/como_utilizar_la_cascara_de_huevo_para_las_plantas_51478_600.webp",
          description: "Llena cada mitad de cáscara con un poco de tierra y coloca una semilla o un planta pequeña.",
        },
        {
          image: "https://www.mdzol.com/u/fotografias/m/2024/3/28/f414x232-1572019_1585758_5050.jpg",
          description: "Una vez que crezcan, planta las cáscaras directamente en la tierra, ya que se biodegradarán.",
        }
      ],
      guide30: [
        {
          image: "images/Materialesimg.png",
            description: "Los materiales que necesitas son:Cáscaras de naranja (en mitades), cera de vela o restos de velas usadas,mechas de algodón y aceites esenciales (opcional)."
        },
        {
          image: "https://haztesostenible.com/wp-content/uploads/2019/05/concha-naranja.jpg",
          description: "Limpia las mitades de naranja y sécalas bien."
        },
        {
          image: "https://www.wikihow.com/images_en/thumb/f/fe/Melt-Beeswax-Step-6-Version-2.jpg/550px-nowatermark-Melt-Beeswax-Step-6-Version-2.jpg",
          description: "Derrite la cera de vela a baño maría y añade unas gotas de aceite esencial si deseas un aroma extra.",
        },
        {
          image: "https://i.pinimg.com/236x/ae/28/d2/ae28d2dcae19db987348b2f0cf3ec9de.jpg",
          description: "Coloca una mecha en el centro de cada mitad de naranja, luego vierte la cera caliente y dejala secar, una vez hecho esto puedes encender tu vela cacera.",
        }
      ],  
          //Termina la session orgànicos//

          //Terminan todas las guias :D (por fin)//
      
    
};
// Esta Funcion Abre el Modal de la Guia seleccionada
function openModal(guideId) {
    currentStep = 0; // Reinicia el pl
    activeGuide = guides[guideId]; // Asigna la guía activa
    updateModal(); // Actualiza el contenido del modal
    document.getElementById('guideModal').style.display = "flex";

    // Esta linea agrega la animacion al cambio de Paso
    const modalContent = document.querySelector('.modal-content');
    modalContent.classList.add('show');
}

// Esta funciona cierra el modal
function closeModal() {
    const modalContent = document.querySelector('.modal-content');
    modalContent.classList.remove('show'); // Remueve la clase de la animacion

    // Con este bloque se espera a que la animación termine antes de ocultar el modal
    setTimeout(() => {
        document.getElementById('guideModal').style.display = "none";
    }, 500); // Define el tiempo de espera
}

// Actualizar el contenido del modal
function updateModal() {
    const step = activeGuide[currentStep];

    // Prepara el contenido para la animación
    const modalContent = document.querySelector('.modal-content');
    modalContent.classList.remove('show'); // Oculta el contenido antes de actualizar

    // Espera a que la animación termine
    setTimeout(() => {
        document.getElementById('stepImage').src = step.image; // Actualiza la imagen
        document.getElementById('stepDescription').innerText = step.description; // Actualiza la descripción
        modalContent.classList.add('show'); // Muestra el nuevo contenido con animación

        // Habilitar o deshabilitar los botones
        document.getElementById('prevBtn').style.display = currentStep === 0 ? 'none' : 'inline';
        document.getElementById('nextBtn').style.display = currentStep === activeGuide.length - 1 ? 'none' : 'inline';
        document.getElementById('completeBtn').style.display = currentStep === activeGuide.length - 1 ? 'inline' : 'none';
    }, 500); // Espera el mismo tiempo que dura la animación para actualizar
}

// Cambia al paso siguiente
function nextStep() {
    if (currentStep < activeGuide.length - 1) {
        currentStep++;
        updateModal();
    } else {
        closeModal(); // Cierra el modal si es el último paso
    }
}

// Cambia al paso anterior
function prevStep() {
    if (currentStep > 0) {
        currentStep--;
        updateModal();
    }
}
document.getElementById("menu-icon").addEventListener("click", function() {
  const sidebar = document.getElementById("sidebarguias");
  sidebar.classList.toggle("active");
});

// Código para el botón de cierre
document.getElementById("close-btn").addEventListener("click", function() {
  const sidebar = document.getElementById("sidebarguias");
  sidebar.classList.remove("active");
});

