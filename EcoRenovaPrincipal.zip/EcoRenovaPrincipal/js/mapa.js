// Aqui se Inicia el mapa en las coordenadas ingresadas
var map = L.map('map').setView([-32.31558473080612, -58.076278828939614], 13);

// Agregar capa para que se vea algo xd
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
//botones de zoom
document.getElementById('zoomIn').onclick = function() {
    map.zoomIn();
};

document.getElementById('zoomOut').onclick = function() {
    map.zoomOut();
};


// Seccion para ubicar marcadores
var locations = [
    {
        name: "Mercado Municipal",
        description: "Este es el mercado municipal de Paysandu",
        products: ["Aceite vegetal usado", "Plastico", "Metal","Carton","Papel","Vidrio"],
        coordinates: [-32.3190040028238, -58.08527305767143],
        conditions: ["Materiales Limpios","Materiales Secos","Materiales compactos"],
        norecibe: ["Residuos Organicos"],
        street: "Sarandi, esquina Montevideo"
    },
    {
        name: "Casa De La Cultura",
        description: "El lugar cuenta con un moderno auditorio, salas para reuniones y conferencias, ademas de ser un sitio que acepta materiales para reciclar.",
        products: [ "Plastico", "Metal","Carton","Papel","Vidrio"],
        conditions: ["Materiales Limpios","Materiales Secos","Materiales compactos"],
        norecibe: ["Residuos Organicos"],
        coordinates: [-32.31763745877034, -58.0897181732562],
        street: "Gral. Leandro Gomez 852"
    },
    {
        name: "COMEPA Servicio de Prevencion y Farmacia",
        description: "Centro de salud privada la cual tambien acepta los productos mencionados.",
        products: ["Envsaes de Medicamentos", "Medicamentos Vencidos"],
        conditions: ["Envases limpios","Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.31700049288534, -58.08736228893602],
        street: "Setembrino 924"
    },
    {
        name: "Barraca Salvador Tortorella",
        description: "El lugar cuenta con la venta de distintos materiales y se unieron al reciclaje.",
        products: [ "Pilas alcalinas","Pilas AA","Pilas AAA","Baterias"],
        conditions: ["En cantidad","En buen estado"],
        norecibe: ["Pilas hinchadas","Pilas con Oxido"],
        coordinates: [-32.31613916588136, -58.090495324609854],
        street: " 18 de Julio y Baltasar Brum"
    },
    {
        name: "Liceo N°1 Élida Heinzen",
        description: "En este liceo de Paysandu aceptan los materiales mencionados",
        products: [ "Pilas alcalinas","Pilas AA","Pilas AAA","Baterias"],
        conditions: [ "En buen estado"],
        norecibe: ["Pilas hinchadas","Pilas con Oxido"],
        coordinates: [-32.31578732570192, -58.09289109458842],
        street: " 18 de Julio y Silvan Fernandez"
    },
    {
        name: "Liceo N°5 ",
        description: "En el liceo 5 de Paysandu aceptan los materiales mencionados",
        products: [ "Plastico", "Metal","Carton","Papel","Vidrio" ],
        conditions: ["Materiales Limpios","Materiales Secos","Materiales compactos"],
        norecibe: ["Materiales Organicos"],
        coordinates: [-32.31536800381983, -58.09261519156932],
        street: "Silvan Fernandez y Florida"
    },
    {
        name: "Farmacia Dorotte Norte",
        description: "Cadena de farmacias la cual tambien acepta los materiales mencionados",
        products: ["Envsaes de Medicamentos", "Medicamentos Vencidos"],
        conditions: ["Envsaes limpios", "Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.30194347740179, -58.08067691409433],
        street: "Roldan y Andresito"
    },
    {
        name: "Farmacia Dorotte I",
        description: "Cadena de farmacias la cual tambien acepta los materiales mencionados",
        products: ["Envsaes de Medicamentos", "Medicamentos Vencidos"],
        conditions: ["Envsaes limpios", "Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.315791468387374, -58.09345368719858],
        street: "18 de Julio y Carlos Albo"
    },
    {
        name: "Farmacia Dorotte II",
        description: "Cadena de farmacias la cual tambien acepta los materiales mencionados",
        products: ["Envsaes de Medicamentos", "Medicamentos Vencidos"],
        conditions: ["Envsaes limpios", "Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.32638725781993, -58.08148388420147],
        street: "Avenida Soriano 1250"
    },
    {
        name: "FerreiraVet",
        description: "En esta Veterinaria se reciben los siguientes materiales",
        products: ["Envases de Medicamentos (uso veterianrio)","Medicamentos Veterinarios Vencidos"],
        conditions: ["Envsaes limpios", "Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.32151699368048, -58.08970215653518],
        street: "Independencia 679"
    },
    {
        name: "Veterinaria Nan",
        description: "En esta Veterinaria se reciben los siguientes materiales",
        products: ["Envases de Medicamentos (uso veterianrio)","Medicamentos Veterinarios Vencidos"],
        conditions: ["Envsaes limpios", "Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.31869692858066, -58.06982698503048],
        street: "Republica Argentina 1696"
    },
    {
        name: "Veterinaria Nan",
        description: "En esta Veterinaria se reciben los siguientes materiales",
        products: ["Envases de Medicamentos (uso veterianrio)","Medicamentos Veterinarios Vencidos"],
        conditions: ["Envsaes limpios", "Medicamentos Vencidos"],
        norecibe: ["Envases sucios","Medicamentos nuevos"],
        coordinates: [-32.31869692858066, -58.06982698503048],
        street: "Republica Argentina 1696"
    },
];

// Agrega marcadores al mapa
locations.forEach(function(location) {
    var marker = L.marker(location.coordinates).addTo(map);
    marker.bindPopup(location.name);

    marker.on('click', function() {
        document.getElementById('info-title').innerText = location.name;
        document.getElementById('info-description').innerText = location.description;
        document.getElementById('info-street').innerText = location.street;

        // Limpiar y añadir productos
        var productsList = document.getElementById('info-products');
        productsList.innerHTML = '';
        location.products.forEach(function(product) {
            var tag = document.createElement('div');
            tag.className = 'tag';
            tag.innerHTML = `<span class="tag-icon"></span>${product}`;
            productsList.appendChild(tag);
        });
        // Limpiar y añadir condiciones
        var conditionsList = document.getElementById('info-conditions'); // Asegúrate de que este ID coincida con el del HTML
        conditionsList.innerHTML = ''; // Cambié 'productsList' por 'conditionsList'
        location.conditions.forEach(function(condition) { // Cambié 'conditions' por 'condition'
            var tag = document.createElement('div');
            tag.className = 'tag';
            tag.innerHTML = `<span class="tag-icon"></span>${condition}`;
            conditionsList.appendChild(tag);
        });

        // Limpiar y añadir elementos de "No Recibe"
        var norecibeList = document.getElementById('info-norecibe');
        norecibeList.innerHTML = '';
        location.norecibe.forEach(function(norecibe) {
            var tag = document.createElement('div');
            tag.className = 'tag';
            tag.innerHTML = `<span class="tag-icon"></span>${norecibe}`;
            norecibeList.appendChild(tag);
        });
        document.getElementById('info').style.display = 'block'; // Mostrar el div de información
    });
});   



document.getElementById('close-info').addEventListener('click', function() {
    document.getElementById('info').style.display = 'none'; // Ocultar el div de información
});

