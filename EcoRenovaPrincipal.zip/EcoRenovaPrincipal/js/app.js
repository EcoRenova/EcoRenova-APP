const iconoBusqueda = document.getElementById('icono-busqueda');
const inputBusqueda = document.getElementById('input-busqueda');
const divBusqueda = document.getElementById('div-busqueda');
const buscarUsuario = document.getElementById('buscar-usuario');

// Mostrar/ocultar el campo de búsqueda al hacer clic en la lupa
iconoBusqueda.addEventListener('click', function() {
    divBusqueda.classList.toggle('mostrar');
});

// Buscar usuario al hacer clic en la lupa
buscarUsuario.addEventListener('click', function() {
    buscarUsuarioFunc();
});

// Buscar usuario al presionar Enter
inputBusqueda.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        buscarUsuarioFunc();
    }
});

// Función para buscar usuario
function buscarUsuarioFunc() {
    const nombreUsuario = inputBusqueda.value.trim();
    if (nombreUsuario) {
        // Redirige a la página de búsqueda
        window.location.href = `buscar.php?usuario=${encodeURIComponent(nombreUsuario)}`;
    } else {
        alert('Por favor, ingresa un nombre de usuario.');
    }
}