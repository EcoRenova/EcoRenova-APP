//Seccion Formulario
const btnLogin = document.getElementById("login");
const btnRegister = document.getElementById("register");
const container = document.querySelector(".container");

// Evento para alternar entre "Iniciar sesión" y "Registrarse"
btnLogin.addEventListener('click', () => {
    container.classList.remove("active"); // Mostrar el formulario de inicio de sesión
});

btnRegister.addEventListener('click', () => {
    container.classList.add("active"); // Mostrar el formulario de registro
});


// Selecciono el formulario que tiene los datos a enviar
const formulario = document.querySelector('form');

// Selectores para los inputs
const input_nombre = document.querySelector("#nombre");
const input_email = document.getElementById("email");
const input_pass = document.getElementById("pass");

//  Campos Relevantes en el objeto datos
const datos = { input_nombre, input_email, input_pass };

formulario.addEventListener("submit", validar_campos);

function validar_campos(evento) {
    let es_valido = true;

    // Recorro el objeto datos que tiene todos los inputs
    for (let campo in datos) {
        // Compruebo si los campos están vacíos
        if (datos[campo].value.trim() === '') {

            // Esto es un mensaje de alerta por si algún campo está vacío
            alert("Todos los campos son obligatorios");
            es_valido = false;
            break;
        }
    }

    // Si no es válido, no se envia el formulario xd
    if (!es_valido) {
        evento.preventDefault();
    }
}

