// Función para mostrar el formulario de edición
function showEditForm() {
    document.getElementById("editFormContainer").style.display = "block"; // Muestra el formulario
}

// Función para ocultar el formulario de edición
function hideEditForm() {
    document.getElementById("editFormContainer").style.display = "none"; // Oculta el formulario
}

// Enviar los datos del formulario suando AJAX
function updateProfile() {
    // Esto obtiene los valores del formulario
    const nombre = document.getElementById("nombre").value;
    const apodo = document.getElementById("apodo").value;

    // Esto valida que ambos campos no estén vacíos
    if (nombre === "" || apodo === "") {
        alert("Por favor, completa todos los campos.");
        return;
    }

    // Aca cree un objeto fromdata para enviar los datos
    const formData = new FormData();
    formData.append("nombre", nombre);
    formData.append("apodo", apodo);

    // Creamos la solicitud AJAX
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "editar_perfil.php", true);

    // función de respuesta cuando el servidor responda (si responde xd)
    xhr.onload = function () { 
        if (xhr.status === 200) {
            // Si la respuesta es exitosa
            document.getElementById("userName").innerText = nombre;
            document.getElementById("userHandle").innerText = "@" + apodo;

            // Ocultar el formulario después de actualizar
            hideEditForm();

            // Mostrar un mensaje de éxito
            alert("Perfil actualizado con éxito.");
        } else {
            // Si hay un error, mostrar mensaje de error
            alert("Hubo un error al actualizar el perfil.");
        }
    };

    // Esto envia los datos al servidor
    xhr.send(formData);
}
