<?php
include 'conexion.php'; 

// conexion con la base de datos
$mysqli = conectar_bd();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recoge datos del formulario
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $etiquetas = $_POST['etiquetas'];
    $precio = $_POST['precio'];
    
    // Comprobar si se subio una imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == UPLOAD_ERR_OK) {
        $imagen = file_get_contents($_FILES['imagen']['tmp_name']);
    } else {
        $imagen = null;
    }
    
    // Preparar y ejecutar la consulta
    $stmt = $mysqli->prepare("INSERT INTO publicaciones_mercado (titulo, descripcion, etiquetas, imagen, precio) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $titulo, $descripcion, $etiquetas, $imagen, $precio);
    
    if ($stmt->execute()) {
        header("Location: indexmercado.php");
        exit();
    } else {
        echo "Error al crear la publicación: " . $stmt->error;
    }
    
    $stmt->close();
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Crear Publicación</title>
    <link rel="stylesheet" href="/css/estilosmercado.css">
</head>
<body>
<div class="hm-wrapper">

<div class="hm-header">
    <div class="container">
        <div class="header-menu">
            <div class="hm-logo">
                <a class="alogo" href="#">
                    <h1 class="logotxt">EcoMarket</h1> 
                </a>
            </div>
            <nav class="hm-menu">
                <ul>
                    <li><a class="volvermercado" href="indexmercado.php">Volver al Mercado</a></li>
                </ul>
                <div class="icon-menu">
                    <button type="button"><i class="fas fa-bars"></i></button>
                </div>
            </nav>
        </div>
    </div>
</div>

<div class="header-menu-movil">
    <button class="cerrar-menu"><i class="fas fa-times"></i></button>
    <ul>
        <li><a href="#">Productos</a></li>
        <li><a href="#">Campañas</a></li>
        <li><a href="#">Nosotros</a></li>
        <li><a href="#">Contacto</a></li>
    </ul>
</div>
    <div class="general-grid-mercado">
    <div class="form-container">
    <h1>Publica tu Producto</h1>
    <p class="publiheadertxt">Rellena el siguiente formulario para poner tu articulo en venta</p>
        <form action="crear_publicacion.php" method="post" enctype="multipart/form-data">
            <label for="titulo">Título:</label>
            <input type="text" autocomplete="off" name="titulo" required>
            
            <label for="descripcion" autocomplete="off">Descripción:</label>
            <textarea name="descripcion" required></textarea>
            
            <label for="etiquetas">Etiquetas:</label>
            <select name="etiquetas" required>
                <option value="decoraciones">Decoraciones</option>
                <option value="bisutería">Bisutería</option>
                <option value="manualidades">Manualidades</option>
                <option value="arte">Arte</option>
            </select>
            
            <label for="precio">Precio:</label>
            <input class="dato" autocomplete="off" type="text" name="precio" required>
            
            <label for="imagen">Imagen:</label>
            <input class="image" type="file" name="imagen">
            
            <button type="submit">Crear Publicación</button>
        </form>
    </div>
</div>
<div class="foo-copy">
            <div class="container">
                <p>EcoRenova Paysandu © Todos los derechos reservados</p>
            </div>
        </div>
</body>
</html>
