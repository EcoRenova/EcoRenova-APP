<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoRenova</title>
    <link rel="stylesheet" href="/css/estilobusqueda.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="logo">

        <img class="logoimg" src="images/LogoEcoRenova.png" alt="">
    </div>
  
    <div class="textconter">

      <h1 class="restitle">Resultados de la Búsqueda de Usuario</h1>
    </div>
  
<main>
    <?php
    require 'conexion.php';

    if (isset($_GET['usuario'])) {
        $apodoUsuario = $_GET['usuario'];
        $mysqli = conectar_bd();

        if ($mysqli->connect_error) {
            die("Error de conexión: " . $mysqli->connect_error);
        }

        $stmt = $mysqli->prepare("SELECT apodo, id_user FROM perfil WHERE apodo LIKE ?");
        
        if ($stmt === false) {
            die("Error en la consulta: " . $mysqli->error);
        }

        $apodoUsuario = "%$apodoUsuario%";
        $stmt->bind_param("s", $apodoUsuario);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            echo "<div class='resultados-busqueda'>";

            while ($fila = $resultado->fetch_assoc()) {
                $stmt_email = $mysqli->prepare("SELECT email FROM usuario WHERE id_user = ?");
                $stmt_email->bind_param("i", $fila['id_user']);
                $stmt_email->execute();
                $resultado_email = $stmt_email->get_result();
                $email = $resultado_email->fetch_assoc()['email'];

                echo "<div class='usuario-busqueda'>
                        <h2>" . htmlspecialchars($fila['apodo']) . "</h2>
                        <p>" . htmlspecialchars($email) . "</p>
                        <div class='botones'>
                            <a href='mantenimiento.html?usuario=" . htmlspecialchars($fila['id_user']) . "' class='button'>Enviar mensaje</a>
                            <a href='perfil_usuarios.php?user_id=" . htmlspecialchars($fila['id_user']) . "' class='button'>Ver perfil</a>
                        </div>
                      </div>";

                $stmt_email->close();
            }

            echo "</div>";
        } else {
            echo "<p class='notuser'>No se encontraron usuarios que coincidan con lo ingresado.</p>";
        }

        $stmt->close();
        $mysqli->close();

    } else {
        echo "<p>No se proporcionó un nombre de usuario para buscar.</p>";
    }
    ?>
</main>
<a class="tobackbtn" href="index.php">⟵</a>
<footer>
    <p>©EcoRenova Paysandu Todos los derechos Reservados</p>
</footer>

</body>
</html>
