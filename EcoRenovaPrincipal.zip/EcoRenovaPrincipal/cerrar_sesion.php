<?php
//Toma la session actual
session_start(); 

// Elimina todas las variables de sesión
$_SESSION = [];

// Destruye la sesión
session_destroy();

// Redirige al usuario a la página de registro o inicio de sesión
header("Location: registrologin.php");
exit();
?>
