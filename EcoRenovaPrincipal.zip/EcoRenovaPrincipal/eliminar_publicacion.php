<?php
require 'conexion.php';

// Verifica si el parámetro id está presente en la solicitud GET
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); 

    // Esto conecta con la base de datos la base de datos
    $mysqli = conectar_bd();

    // Esto prepara la consulta de eliminación
    $query = "DELETE FROM publicaciones_mercado WHERE id = ?";
    if ($stmt = $mysqli->prepare($query)) {
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            // Redirigir al índice después de eliminar
            header("Location: indexmercado.php");
            exit();
        } else {
            echo 'Error al eliminar la publicación.';
        }
        $stmt->close();
    } else {
        echo 'Error en la consulta.';
    }

    $mysqli->close();
} else {
    echo 'Solicitud no válida.';
}
?>
