<?php
session_start();

// Verifica si el usuario inicio sesión
if (!isset($_SESSION['email'])) {
    header('Location: login_user.php'); // Redirige si no está logueado
    exit();
}
// Esto conecta con la base de datos
require 'conexion.php';
$con = conectar_bd(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Guias-EcoRenova</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
	<!-- Bootstrap core CSS -->
	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<!-- Fontawesome CSS -->
	<link href="css/all.css" rel="stylesheet">
	<!-- Custom styles for this template -->
	<link href="css/style.css" rel="stylesheet">
	<!-- Leaflet CSS -->
	<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
</head>
<body class="guias">
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-light top-nav fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
            <img class="logoimg" src="images/LogoEcoRenova.png" alt="logo" />
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                     <a class="nav-link active" href="index.php">Inicio</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="sobrenosotros.html">Nosotros</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="indexmercado.php">EcoMarket</a>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Foro
                     </a>
                     <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                        <a class="dropdown-item" href="inicioforo.html">Inicio</a>
                        <a class="dropdown-item" href="foro.php">principal</a>
                    </div>
                  </li>
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span style="
            color: #00ff00; 
            background-color: green;
            border-radius: 20px; 
            padding: 0.5em 1em; 
            border: 2px solid #00ff00; 
            font-weight: bold; 
            display: inline-block; 
            text-align: center;
            font-size: 12px;
        ">
            <?php echo htmlspecialchars($_SESSION['apodo']); ?>
        </span>
    </a>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
        <a class="dropdown-item" href="verperfil.php">Ver</a>
        <form action="cerrar_sesion.php" method="post">
            <button type="submit" class="dropdown-item">Cerrar Sesión</button>
        </form>
    </div>
                  </li>
               </ul>
            </div>
        </div>
    </nav>
	<div class="full-title">
		<div class="container">
			<h1 class="mt-4 mb-3">Guias/Inicio
			</h1>
		</div>
	</div>

    <div class="container">
		<div class="breadcrumb-main">
			<ol class="breadcrumb">
				<li class="breadcrumb-item">
					<a href="index.html">Inicio</a>
				</li>
				<li class="breadcrumb-item active">Guias</li>
			</ol>
		</div>  
         
        <div class="guiasconterflex">
        <div class="portfolio-main">
            <h2 class="guidestitle">Nuestras Guias</h2>
            <div class="row">
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="plasticos.html">
                           <img class="card-img-top" src="images/plasticos.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="plasticos.html">Reciclaje de Plasticos</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="papel_carton.html">
                           <img class="card-img-top" src="images/papel-carton.jpg" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="papel_carton.html">Reciclaje de Papel y Carton</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="mantenimiento.html">
                           <img class="card-img-top" src="images/vidrio.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="mantenimiento.html">Reciclaje de Vidrio</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="mantenimiento.html">
                           <img class="card-img-top" src="images/metales.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="mantenimiento.html">Reciclaje de Metales</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="mantenimiento.html">
                           <img class="card-img-top" src="images/electro.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="electronicos.html">Reciclaje de Electronicos</a>
                        </h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-sm-6 portfolio-item">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="mantenimiento.html">
                           <img class="card-img-top" src="images/organicos.jpg" alt="" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="mantenimiento.html">Reciclaje de Organicos</a>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
        </div>
      </div>
      </div>
      <!-- Inicio Del Footer -->
<footer class="footer">
   <div class="container bottom_border">
       <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6 col">
          <h5 class="headin5_amrc col_white_amrc pt2">Contactanos</h5>
          <!--Info y contacto -->
          <p class="mb10">Aqui puedes encontrar nuestra informacion de contacto</p>
          <p><i class="fa fa-location-arrow"></i> Leandro Gómez N°1167, entre Dr. A. de Herrera y Zorrilla de San Martín. </p>
          <p><i class="fa fa-phone"></i> +472849784 </p>
          <p><i class="fa fa fa-envelope"></i> ecorenovapaysandu01@gmail.com </p>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6 col">
          <h5 class="headin5_amrc col_white_amrc pt2">Siguenos</h5>
          <!--Redes Sociales Links-->
          <ul class="footer_ul2_amrc">
             <li>
                <a href="#"><i class="fab fa-twitter fleft padding-right"></i> </a>
                <p>Siguenos en Twitter<a href="https://x.com/eco_renova_pay/"> Aqui</a></p>
             </li>
             <li>
                <a href="#"><i class="fab fa-instagram fleft padding-right"></i> </a>
                <p>Siguenos en Instagram<a href="https://www.instagram.com/eco_renova_pay/"> Aqui</a></p>
             </li>
             <li>
                <a href="#"><i class="fab fa-facebook-f fleft padding-right"></i> </a>
                <p>Siguenos en Facebook<a href="#"> Aqui</a></p>
             </li>
          </ul>
          <!--Terminacion del Footer-->
       </div>
       <div class="col-lg-3 col-md-6 col-sm-6">
          <h5 class="headin5_amrc col_white_amrc pt2">Links Rapidos</h5>
          <ul class="footer_ul_amrc">
             <li><a href="#">Foro</a></li>
             <li><a href="#">EcoMarket</a></li>
             <li><a href="#">Mapa </a></li>
             <li><a href="#">Nosotros</a></li>
             <li><a href="#">Serivicios</a></li>
          </ul>
       </div>
       <div class="col-lg-3 col-md-6 col-sm-6 ">
          <h5 class="headin5_amrc col_white_amrc pt2">Nuestras Ultimas Guias</h5>
          <ul class="footer_ul_amrc">
             <li class="media">
                <div class="media-left">
                   <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnVUsd58IgcwR99RKzarMP1UGplfmffuPoHg&s" alt="" />
                </div>
                <div class="media-body">
                   <p>Como hacer Papel reciclado?</p>
                   <a href="papel_carton.html">ir</a>
                </div>
             </li>
             <li class="media">
                <div class="media-left">
                   <img class="img-fluid" src="images/alcancia.jpg" alt="" />
                </div>
                <div class="media-body">
                   <p>Alcancia con botellas?</p>
                   <a href="plasticos.html">ir</a>
                </div>
             </li>
             <li class="media">
                <div class="media-left">
                   <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXrkfsVJq3obQ0B_sL-Esfnnfdt_5f0pbjdQ&s" alt="" />
                </div>
                <div class="media-body">
                   <p>Costurero con Caja de huevos</p>
                   <a href="papel_carton.html">ir</a>
                </div>
             </li>
          </ul>
       </div>
    </div>
 </div>
   <div class="container">
       <div class="footer-logo">
       <a href="#"><img class="footerimg" src="images/LogoEcoRenova.png" alt="" /></a>
    </div>
       <!--Aca termina el bottom del Fotter-->
       <p class="copyright text-center">Todo los Derechos Reservados. &copy; 2024 <a href="#">EcoRenovaPaysandu</a>
       </p>
       <ul class="social_footer_ul">
       <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
       <li><a href="https://x.com/eco_renova_pay/"><i class="fab fa-twitter"></i></a></li>
       <li><a href="https://www.instagram.com/eco_renova_pay/"><i class="fab fa-instagram"></i></a></li>
       </ul>
       <!-- Aca Termina El Footer -->
   </div>
</footer>
<!-- Bootstrap y JavaScripts conexiones -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
</body>
</html>
