<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="/css/stylereglog.css">
    <title>Login/Registro</title>
</head>
<body>
    <div class="container" id="container">
        <div class="form-container sign-up">
            <form action="registro_user.php" method="post" onsubmit="return validateForm()">
                <h1>Crea una Cuenta</h1>
                <span>Usa tu correo para registrarte</span>
                <input id="nombre" type="text" name="nombre" autocomplete="off" placeholder="Nombre" required maxlength="15">
                <input id="emailReg" type="email" name="email" autocomplete="off" placeholder="Email" required maxlength="35" 
                pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" title="Introduce un correo válido. Ejemplo: santicerrudo@gmail.com">
                
                <!-- Campo de contraseña con botón para mostrar/ocultar -->
                <div class="password-container">
                    <input id="passReg" type="password" name="pass" autocomplete="off" placeholder="Contraseña" required minlength="8" maxlength="16">
                    <button type="button" class="password-toggle" id="togglePassReg">
                        <i class="fa-solid fa-eye-slash"></i>
                    </button>
                </div>

                <button type="submit">Registrarme</button>
            </form>
        </div>

        <div class="form-container sign-in">
            <form action="login_user.php" method="post" onsubmit="return validateLoginForm()">
                <input type="hidden" name="action" value="login"> <!-- Campo oculto para la acción -->
                <h1>Iniciar Sesión</h1>
                <span>Usa tu email y contraseña</span>
                <input id="emailLog" type="email" name="email" autocomplete="off" placeholder="Email" required maxlength="35" 
                pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" title="Introduce un correo válido. Ejemplo: santicerrudo@gmail.com">
                
                <div class="password-container">
                    <input id="passLog" type="password" name="pass" autocomplete="off" placeholder="Contraseña" required minlength="8" maxlength="16">
                    <button type="button" class="password-toggle" id="togglePassLog">
                        <i class="fa-solid fa-eye-slash"></i>
                    </button>
                </div>

                <button type="submit">Iniciar Sesión</button>
            </form>
        </div>

        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Hola, te damos la bienvenida a EcoRenova, aquí puedes registrarte.</h1>
                    <p>Pone tus datos personales para utilizar todas las funciones del sitio</p>
                    <button class="hidden" id="login">Iniciar Sesión</button>
                </div>
                <div class="toggle-panel toggle-right">
                    <h1>Bienvenido de nuevo a nuestro sitio, inicia sesión aquí</h1>
                    <p>Pone tus datos personales para utilizar todas las funciones del sitio</p>
                    <button class="hidden" id="register">Registrarme</button>
                </div>
            </div>
        </div>
    </div>

    <script src="/js/registrologin.js"></script>
    <script src="/js/formularioreglog.js"></script>

    <script>
        // Validación con JS
        function validateForm() {
            const nombre = document.getElementById('nombre').value;
            const emailReg = document.getElementById('emailReg').value;
            const passwordReg = document.getElementById('passReg').value;

            // Validar el nombre
            if (nombre.length > 15) {
                alert('El nombre no puede tener más de 15 caracteres.');
                return false;
            }

            // Validar la contraseña
            if (passwordReg.length < 8 || passwordReg.length > 16) {
                alert('La contraseña debe tener entre 8 y 16 caracteres.');
                return false;
            }

            return true; //si todo esta GOD
        }

        function validateLoginForm() {
            const emailLog = document.getElementById('emailLog').value;
            const passwordLog = document.getElementById('passLog').value;

            // parametros para las contraseñas
            if (passwordLog.length < 8 || passwordLog.length > 16) {
                alert('La contraseña debe tener entre 8 y 16 caracteres.');
                return false;
            }

            return true; // Si todo es GOD
        }

        // Funcionalidad para mostrar/ocultar contraseña
        document.getElementById('togglePassReg').addEventListener('click', function() {
            const passwordField = document.getElementById('passReg');
            const icon = this.querySelector('i');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        });

        document.getElementById('togglePassLog').addEventListener('click', function() {
            const passwordField = document.getElementById('passLog');
            const icon = this.querySelector('i');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                passwordField.type = 'password';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        });
    </script>
</body>
</html>
