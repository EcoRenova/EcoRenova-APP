<?php
include 'conexion.php';
session_start();

// Esto conecta con la base de datos
$mysqli = conectar_bd();

// Consulta la tabla publicaciones apodo del usuario
$query = "
    SELECT 
        fp.id_publicacion, 
        fp.titulo, 
        fp.contenido, 
        fp.imagen, 
        fp.fecha_publicacion,
        fp.id_user,
        (SELECT p.apodo FROM perfil p WHERE p.id_user = fp.id_user) AS apodo
    FROM foro_publicaciones fp
    ORDER BY fp.fecha_publicacion DESC";

$result = $mysqli->query($query);

// Obtener el ID del usuario actual
$id_user_actual = null;
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    $query_user = "
        SELECT u.id_user 
        FROM usuario u 
        WHERE u.email = ?";
    $stmt_user = $mysqli->prepare($query_user);
    $stmt_user->bind_param("s", $email);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    $user = $result_user->fetch_assoc();
    $id_user_actual = $user['id_user'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Foro</title>
    <link rel="stylesheet" href="/css/foroestilo.css">
</head>
<body class="foroprinci">
    <header>
        <img class="logoimg" src="images/LogoEcoRenova.png" alt="">
    </header>
    <a href="index.php" class="btn-regresar">Inicio</a> <!-- Botón para ir a index.php -->
    
    <div class="seccionforodiv">
      <h1 class="seccionforotitle">Principal</h1>
    </div>
    
    <nav>
         <a href="crear_publicacion_foro.php" class="btn-crear">Crear Publicación</a>
    </nav>

    <div class="publicaciones-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="publicacion">
                    
                <div class="contenido-publicacion">
                    <h3><?php echo htmlspecialchars($row['titulo']); ?></h3>
                    <p><?php echo htmlspecialchars($row['contenido']); ?></p>
                    <?php if ($row['imagen']): ?>
                        <img class="imgforopubli" src="<?php echo htmlspecialchars($row['imagen']); ?>" alt="Imagen de la publicación">
                    <?php endif; ?>
                </div>
                <small class="fecha">Publicado el: <?php echo $row['fecha_publicacion']; ?></small> 
                <br>
                <small class="autor">Autor: <?php echo htmlspecialchars($row['apodo']); ?></small>
            
                <?php if ($id_user_actual == $row['id_user']): ?>
                    <form action="borrar_publicacion.php" method="POST" onsubmit="return confirm('¿Estás seguro de que quieres eliminar esta publicación?');">
                        <input type="hidden" name="id_publicacion" value="<?php echo $row['id_publicacion']; ?>">
                        <button type="submit" class="btn-eliminar">Eliminar</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
