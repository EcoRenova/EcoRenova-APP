<?php
require("conexion.php");

$con = conectar_bd();

if (isset($_POST["action"]) && $_POST["action"] === "login") {
    $email = mysqli_real_escape_string($con, $_POST["email"]);
    $contrasenia = $_POST["pass"];

    // Llamada a la función login
    logear($con, $email, $contrasenia);
}

function logear($con, $email, $pass) {
    session_start();

    // Consulta para obtener los datos de la tabla usuario
    $consulta_login = "SELECT * FROM usuario WHERE email = '$email'";
    $resultado_login = mysqli_query($con, $consulta_login);

    if (mysqli_num_rows($resultado_login) > 0) {
        $fila = mysqli_fetch_assoc($resultado_login);
        $password_bd = $fila["pass"];

        if (password_verify($pass, $password_bd)) {
            $_SESSION["user_id"] = $fila["id_user"];
            $_SESSION["email"] = $email;
            $_SESSION["nombre"] = $fila["nombre"]; 

            // Consulta adicional para obtener el apodo desde la tabla perfil
            $id_user = $fila["id_user"];
            $consulta_perfil = "SELECT apodo FROM perfil WHERE id_user = '$id_user'";
            $resultado_perfil = mysqli_query($con, $consulta_perfil);

            if (mysqli_num_rows($resultado_perfil) > 0) {
                $fila_perfil = mysqli_fetch_assoc($resultado_perfil);
                $_SESSION["apodo"] = $fila_perfil["apodo"];
            } else {
                // Valor por defecto si no hay apodo
                $_SESSION["apodo"] = 'Usuario'; 
            }

            header("Location: index.php");
            exit();
        } else {
            echo "Contraseña incorrecta";
        }
    } else {
        echo "Usuario no encontrado";
    }

    mysqli_close($con);
}

